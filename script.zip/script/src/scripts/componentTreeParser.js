const { getAbsolutePath } = require("../../utils/resolver.js");
const { DIRECTORY } = require("../../constants.js");
const { parse } = require("@babel/parser");
const path = require("path");
const fs = require("fs");
const { getNonce } = require("../../utils/getNonce.js");
const swc = require("@swc/core");
const { NaryTree } = require("../classes/NaryTree.js");

function findParameterNamesMainComponent(functionName, paramArray, tree) {
  return {
    // handle the case of arrow functions
    enter(node) {
      if (
        node.type === "VariableDeclarator" &&
        node.id?.type === "Identifier"
      ) {
        if (
          node.id?.value === functionName &&
          node.init?.type === "ArrowFunctionExpression"
        ) {
          let parameters = node.init.params;
          parameters.forEach((argument) => {
            // normal
            if (argument.type === "Identifier") {
              paramArray.push(argument.value);
              tree.insert(argument.value);
            }

            // destructured object pattern
            if (argument.type === "ObjectPattern") {
              tree.insert("props");
            }

            // destructured array pattern
            if (argument.type === "ArrayPattern") {
              tree.insert("props");
              argument.elements.forEach((element) => {
                if (element.type === "Identifier") {
                  tree.insert(element.value, "props");
                  paramArray.push(element.value);
                }
              });
            }
          });
        } else if (
          node.id?.value === functionName &&
          node.init?.type === "CallExpression" &&
          node.init?.arguments[0]?.expression?.type ===
            "ArrowFunctionExpression"
        ) {
          let parameters = node.init.arguments[0].expression.params;
          parameters.forEach((argument) => {
            // normal
            if (argument.type === "Identifier") {
              paramArray.push(argument.value);
              tree.insert(argument.value);
            }

            // destructured object pattern
            if (argument.type === "ObjectPattern") {
              tree.insert("props");
            }

            // destructured array pattern
            if (argument.type === "ArrayPattern") {
              tree.insert("props");
              argument.elements.forEach((element) => {
                if (element.type === "Identifier") {
                  tree.insert(element.value, "props");
                  paramArray.push(element.value);
                }
              });
            }
          });
        }
      }

      // handle the case of normal function declarations
      if (
        (node.type === "FunctionDeclaration" ||
          node.type === "FunctionExpression") &&
        node.identifier?.type === "Identifier" &&
        node.identifier?.value === functionName
      ) {
        node.params.forEach((argument) => {
          if (argument.type === "Parameter") {
            // normal
            if (argument.pat?.type === "Identifier") {
              paramArray.push(argument.pat.value);
              tree.insert(argument.pat.value);
            }

            // destructured object pattern
            else if (argument.pat?.type === "ObjectPattern") {
              tree.insert("props");
            }

            // destructured array pattern
            else if (argument.pat?.type === "ArrayPattern") {
              argument.pat.elements.forEach((element) => {
                if (element.type === "Identifier") {
                  paramArray.push(element.value);
                  tree.insert(element.value, "props");
                }
              });
            }
          }
        });
      }
    },
  };
}

function getRestOperatorMaps(map, functionName, tree, propsPassed) {
  return {
    enter(node) {
      if (
        node.type === "VariableDeclarator" &&
        node.id?.type === "ObjectPattern" &&
        node.init?.type === "Identifier" &&
        node.init?.value === tree.getRootNode().value
      ) {
        let key = "none";
        let currDestructuredProps = new Set();
        const properties = node.id.properties;
        properties.forEach((arg) => {
          if (
            arg.type === "RestElement" &&
            arg.argument?.type === "Identifier"
          ) {
            key = arg.argument?.value;
          } else if (
            (arg.type === "KeyValuePatternProperty" ||
              arg.type === "AssignmentPatternProperty") &&
            arg.key?.type === "Identifier"
          ) {
            currDestructuredProps.add(arg.key?.value);
          }
        });

        if (key !== "none") {
          const difference = propsPassed.filter(
            (prop) => !currDestructuredProps.has(prop)
          );
          map.set(key, difference);
        }
      } else if (
        node.type === "VariableDeclarator" &&
        node.id?.type === "Identifier"
      ) {
        if (
          node.id?.value === functionName &&
          node.init?.type === "ArrowFunctionExpression"
        ) {
          let parameters = node.init?.params;
          let key = "none";
          let currDestructuredProps = new Set();

          if (parameters[0]?.type === "ObjectPattern") {
            parameters[0]?.properties.forEach((arg) => {
              if (
                arg.type === "RestElement" &&
                arg.argument?.type === "Identifier"
              ) {
                key = arg.argument?.value;
              } else if (
                (arg.type === "KeyValuePatternProperty" ||
                  arg.type === "AssignmentPatternProperty") &&
                arg.key?.type === "Identifier"
              ) {
                currDestructuredProps.add(arg.key?.value);
              }
            });
            if (key !== "none") {
              const difference = propsPassed.filter(
                (prop) => !currDestructuredProps.has(prop)
              );
              map.set(key, difference);
            }
          }
        } else if (
          node.id?.value === functionName &&
          node.init?.type === "CallExpression" &&
          node.init?.arguments[0]?.expression?.type ===
            "ArrowFunctionExpression"
        ) {
          let key = "none";
          let currDestructuredProps = new Set();
          let parameters = node.init.arguments[0].expression.params;
          if (parameters[0]?.type === "ObjectPattern") {
            parameters[0]?.properties.forEach((arg) => {
              if (
                arg.type === "RestElement" &&
                arg.argument?.type === "Identifier"
              ) {
                key = arg.argument?.value;
              } else if (
                (arg.type === "KeyValuePatternProperty" ||
                  arg.type === "AssignmentPatternProperty") &&
                arg.key?.type === "Identifier"
              ) {
                currDestructuredProps.add(arg.key?.value);
              }
            });
            if (key !== "none") {
              const difference = propsPassed.filter(
                (prop) => !currDestructuredProps.has(prop)
              );
              map.set(key, difference);
            }
          }
        }
      }

      // handle the case of normal function declarations
      if (
        (node.type === "FunctionDeclaration" ||
          node.type === "FunctionExpression") &&
        node.identifier?.type === "Identifier" &&
        node.identifier?.value === functionName
      ) {
        if (node.params[0]?.pat?.type === "ObjectPattern") {
          let key = "none";
          let currDestructuredProps = new Set();
          const properties = node.params[0]?.pat?.properties;
          properties.forEach((arg) => {
            if (
              arg.type === "RestElement" &&
              arg.argument?.type === "Identifier"
            ) {
              key = arg.argument?.value;
            } else if (
              (arg.type === "KeyValuePatternProperty" ||
                arg.type === "AssignmentPatternProperty") &&
              arg.key?.type === "Identifier"
            ) {
              currDestructuredProps.add(arg.key?.value);
            }
          });
          if (key !== "none") {
            const difference = propsPassed.filter(
              (prop) => !currDestructuredProps.has(prop)
            );
            map.set(key, difference);
          }
        }
      }
    },
  };
}

function traverse(node, visitor) {
  if (!node || typeof node !== "object") return;
  if (Array.isArray(node)) {
    node.forEach((child) => traverse(child, visitor));
  } else {
    if (visitor.enter) visitor.enter(node);
    Object.keys(node).forEach((key) => {
      if (key !== "loc") traverse(node[key], visitor);
    });
    if (visitor.exit) visitor.exit(node);
  }
}

function getActualComponent(componentName, actualComponent) {
  return {
    enter(node) {
      if (
        node.type === "VariableDeclarator" &&
        node.id?.type === "Identifier" &&
        node.id?.value === componentName
      ) {
        if (node.init?.type === "CallExpression") {
          actualComponent.push(node.init?.arguments[0]?.expression?.value);
        }
      }
    },
  };
}

let functionBodyNode;
function getFunctionBodyNode(functionName) {
  return {
    enter(node) {
      if (
        node.type === "VariableDeclarator" &&
        node.id?.type === "Identifier" &&
        node.id?.value === functionName
      ) {
        if (node.init?.type === "ArrowFunctionExpression") {
          functionBodyNode = node.init.body;
        }
        if (
          node.init?.type === "CallExpression" &&
          node.init?.arguments[0]?.expression?.type ===
            "ArrowFunctionExpression"
        ) {
          functionBodyNode = node.init?.arguments[0]?.expression.body;
        }
      } else if (
        (node.type === "FunctionDeclaration" ||
          node.type === "FunctionExpression") &&
        node.identifier?.type === "Identifier" &&
        node.identifier?.value === functionName
      ) {
        functionBodyNode = node.body;
      }
    },
  };
}

function getActualComponentPathVisitor(
  functionName,
  absolutePath,
  actualComponentPath
) {
  return {
    enter(node) {
      if (node.type === "ExportNamedDeclaration") {
        node.specifiers?.forEach((exp) => {
          if (
            exp.type === "ExportSpecifier" &&
            exp.orig?.type === "Identifier"
          ) {
            if (exp.orig?.value === functionName) {
              const relPath = node.source?.value;
              const actualPath = getAbsolutePath(
                DIRECTORY,
                absolutePath,
                relPath
              );
              if (fs.existsSync(actualPath)) {
                actualComponentPath.push(actualPath);
              } else {
                actualComponentPath.push(absolutePath);
              }
            } else if (
              exp.orig?.value === "default" &&
              ((exp.exported?.type === "Identifier" &&
                exp.exported?.value === functionName) ||
                exp.exported === null)
            ) {
              const relPath = node.source?.value;
              const actualPath = getAbsolutePath(
                DIRECTORY,
                absolutePath,
                relPath
              );
              if (fs.existsSync(actualPath)) {
                actualComponentPath.push(actualPath);
              } else {
                actualComponentPath.push(absolutePath);
              }
            }
          }
        });
      } else if (
        node.type === "ExportAllDeclaration" &&
        node.source.type === "StringLiteral"
      ) {
        const relPath = node.source.value;
        const actualPath = getAbsolutePath(DIRECTORY, absolutePath, relPath);
        if (fs.existsSync(actualPath)) {
          const jsxFilePath = actualPath;
          const jsxCode = fs.readFileSync(jsxFilePath, "utf8");
          const ast = swc.parseSync(jsxCode, {
            syntax: "typescript",
            tsx: true,
          });
          functionBodyNode = "null";
          traverse(ast, getFunctionBodyNode(functionName));
          if (functionBodyNode !== "null") {
            actualComponentPath.push(actualPath);
          }
        }
      } else if (node.type === "ImportDeclaration") {
        node.specifiers?.forEach((element) => {
          if (element.local?.type === "Identifier") {
            if (
              (element.type === "ImportSpecifier" ||
                element.type === "ImportDefaultSpecifier") &&
              element.local?.value === functionName
            ) {
              const relPath = node.source?.value;
              const actualPath = getAbsolutePath(
                DIRECTORY,
                absolutePath,
                relPath
              );
              if (fs.existsSync(actualPath)) {
                actualComponentPath.push(actualPath);
              }
            } else if (
              element.type === "ImportNamespaceSpecifier" &&
              element.source?.type === "StringLiteral"
            ) {
              const relPath = node.source?.value;
              const actualPath = getAbsolutePath(
                DIRECTORY,
                absolutePath,
                relPath
              );
              if (fs.existsSync(actualPath)) {
                const jsxFilePath = actualPath;
                const jsxCode = fs.readFileSync(jsxFilePath, "utf8");
                const ast = swc.parseSync(jsxCode, {
                  syntax: "typescript",
                  tsx: true,
                });
                functionBodyNode = "null";
                traverse(ast, getFunctionBodyNode(functionName));
                if (functionBodyNode !== "null") {
                  actualComponentPath.push(actualPath);
                }
              }
            }
          }
        });
      }
    },
  };
}

function getActualComponentPath(
  functionName,
  parentFilePath,
  relativeImport,
  actualComponentPath
) {
  const absolutePath = getAbsolutePath(
    DIRECTORY,
    parentFilePath,
    relativeImport
  );
  if (absolutePath.includes("node_modules")) {
    actualComponentPath.push(absolutePath);
  } 
  else if (absolutePath.includes("package.json")) {
    fs.readFile(absolutePath, 'utf8', (err, data) => {
      if (err) {
        console.error('Error reading package.json file:', err);
        return;
      }
      // Parse the JSON data
      try {
        const packageJson = JSON.parse(data);
        // Extract the 'main' field
        const relPath = packageJson.main;
        const actualPath = getAbsolutePath(
          DIRECTORY,
          absolutePath,
          relPath
        );
        actualComponentPath.push(actualPath);
      } catch (err) {
        console.error('Error parsing JSON:', err);
      }
    });
  }
  else if (
    !absolutePath.includes("index.js") &&
    !absolutePath.includes("index.ts") &&
    !absolutePath.includes("index.tsx")
  ) {
    actualComponentPath.push(absolutePath);
  } else {
    const jsxFilePath = absolutePath;
    const jsxCode = fs.readFileSync(jsxFilePath, "utf8");
    // Generate ast
    const ast = swc.parseSync(jsxCode, {
      syntax: "typescript",
      tsx: true,
    });
    traverse(
      ast,
      getActualComponentPathVisitor(
        functionName,
        absolutePath,
        actualComponentPath
      )
    );
    if (actualComponentPath.length === 0) {
      actualComponentPath.push(absolutePath);
    }
  }
}

const __assign =
  (this && this.__assign) ||
  function () {
    __assign =
      Object.assign ||
      function (t) {
        for (let s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];
          for (const p in s)
            if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
      };
    return __assign.apply(this, arguments);
  };

class Parser {
  constructor(filePath) {
    // Fix when selecting files in wsl file system
    this.entryFile = filePath;
    if (process.platform === "linux" && this.entryFile.includes("wsl$")) {
      this.entryFile = path.resolve(
        filePath.split(path.win32.sep).join(path.posix.sep)
      );
      this.entryFile = "/" + this.entryFile.split("/").slice(3).join("/");
      // Fix for when running wsl but selecting files held on windows file system
    } else if (
      process.platform === "linux" &&
      /[a-zA-Z]/.test(this.entryFile[0])
    ) {
      const root = `/mnt/${this.entryFile[0].toLowerCase()}`;
      this.entryFile = path.join(
        root,
        filePath.split(path.win32.sep).slice(1).join(path.posix.sep)
      );
    }
    this.tree = undefined;
  }

  // Public method to generate component tree based on current entryFile
  parse() {
    const root = {
      id: getNonce(),
      name: path.basename(this.entryFile).replace(/\.(t|j)sx?$/, ""),
      fileName: path.basename(this.entryFile),
      filePath: this.entryFile,
      importPath: "/", // this.entryFile here breaks windows file path on root e.g. C:\\ is detected as third party
      expanded: false,
      depth: 0,
      count: 1,
      thirdParty: false,
      reactRouter: false,
      reduxConnect: false,
      children: [],
      parentList: [],
      props: {},
      error: "",
    };
    this.tree = root;
    this.parser(root);
    return this.tree;
  }

  getTree() {
    return this.tree;
  }

  // Set Sapling Parser with a specific Data Tree (from workspace state)
  setTree(tree) {
    this.entryFile = tree.filePath;
    this.tree = tree;
  }

  updateTree(filePath) {
    let children = [];
    const getChildNodes = (node) => {
      const { depth, filePath, expanded } = node;
      children.push({ depth, filePath, expanded });
    };

    const matchExpand = (node) => {
      for (let i = 0; i < children.length; i += 1) {
        const oldNode = children[i];
        if (
          oldNode.depth === node.depth &&
          oldNode.filePath === node.filePath &&
          oldNode.expanded
        ) {
          node.expanded = true;
        }
      }
    };

    const callback = (node) => {
      if (node.filePath === filePath) {
        node.children.forEach((child) => {
          this.traverseTree(getChildNodes, child);
        });
        const newNode = this.parser(node);
        this.traverseTree(matchExpand, newNode);
        children = [];
      }
    };

    this.traverseTree(callback, this.tree);
    return this.tree;
  }

  // Traverses the tree and changes expanded property of node whose id matches provided id
  toggleNode(id, expanded) {
    const callback = (node) => {
      if (node.id === id) {
        node.expanded = expanded;
      }
    };
    this.traverseTree(callback, this.tree);
    return this.tree;
  }

  // Traverses all nodes of current component tree and applies callback to each node
  traverseTree(callback, node = this.tree) {
    if (!node) {
      return;
    }
    callback(node);
    node.children.forEach((childNode) => {
      this.traverseTree(callback, childNode);
    });
  }

  // Recursively builds the React component tree structure starting from root node
  parser(componentTree) {
    // If import is a node module, do not parse any deeper
    if (!["\\", "/", "."].includes(componentTree.importPath[0])) {
      componentTree.thirdParty = true;
      if (
        componentTree.fileName === "react-router-dom" ||
        componentTree.fileName === "react-router"
      ) {
        componentTree.reactRouter = true;
      }
      return;
    }
    // Check that file has valid fileName/Path, if not found, add error to node and halt
    const fileName = this.getFileName(componentTree);
    if (!fileName) {
      componentTree.error = "File not found.";
      return;
    }
    // If current node recursively calls itself, do not parse any deeper:
    if (componentTree.parentList.includes(componentTree.filePath)) {
      return;
    }
    // Create abstract syntax tree of current component tree file
    let ast;
    try {
      ast = parse(
        fs.readFileSync(path.resolve(componentTree.filePath), "utf-8"),
        {
          sourceType: "module",
          tokens: true,
          plugins: ["jsx", "typescript"],
        }
      );
    } catch (err) {
      componentTree.error = "Error while processing this file/node";
      return componentTree;
    }
    // Find imports in the current file, then find child components in the current file
    const imports = this.getImports(ast.program.body);
    // Get any JSX Children of current file:
    if (ast.tokens) {
      componentTree.children = this.getJSXChildren(
        ast.tokens,
        imports,
        componentTree
      );
    }
    // Check if current node is connected to the Redux store
    if (ast.tokens) {
      componentTree.reduxConnect = this.checkForRedux(ast.tokens, imports);
    }
    // Recursively parse all child components
    componentTree.children.forEach((child) => this.parser(child));
    return componentTree;
  }

  // Finds files where import string does not include a file extension
  getFileName(componentTree) {
    const ext = path.extname(componentTree.filePath);
    let fileName = componentTree.fileName;
    if (!ext) {
      // Try and find file extension that exists in directory:
      const fileArray = fs.readdirSync(path.dirname(componentTree.filePath));
      const regEx = new RegExp(`${componentTree.fileName}\.(j|t)sx?$`);
      fileName = fileArray.find((fileStr) => fileStr.match(regEx));
      if (fileName) componentTree.filePath += path.extname(fileName);
    }
    return fileName;
  }

  // Extracts Imports from current file
  // const Page1 = lazy(() => import('./page1')); -> is parsed as 'ImportDeclaration'
  // import Page2 from './page2'; -> is parsed as 'VariableDeclaration'
  getImports(body) {
    const bodyImports = body.filter(
      (item) => item.type === "ImportDeclaration" || "VariableDeclaration"
    );
    return bodyImports.reduce((accum, curr) => {
      // Import Declarations:
      if (curr.type === "ImportDeclaration") {
        curr.specifiers.forEach((i) => {
          accum[i.local.name] = {
            importPath: curr.source.value,
            importName: i.imported ? i.imported.name : i.local.name,
          };
        });
      }
      // Imports Inside Variable Declarations:
      if (curr.type === "VariableDeclaration") {
        const importPath = this.findVarDecImports(curr.declarations[0]);
        if (importPath) {
          const importName = curr.declarations[0].id.name;
          accum[curr.declarations[0].id.name] = {
            importPath: importPath,
            importName: importName,
          };
        }
      }
      return accum;
    }, {});
  }

  // Recursive helper method to find import path in Variable Declaration
  findVarDecImports(ast) {
    // Base Case, find import path in variable declaration and return it,
    if (ast.hasOwnProperty("callee") && ast.callee.type === "Import") {
      return ast.arguments[0].value;
    }
    // Otherwise look for imports in any other non null/undefined objects in the tree:
    for (const key in ast) {
      if (ast.hasOwnProperty(key) && typeof ast[key] === "object" && ast[key]) {
        const importPath = this.findVarDecImports(ast[key]);
        if (importPath) {
          return importPath;
        }
      }
    }
    return false;
  }

  // Finds JSX React Components in current file
  getJSXChildren(astTokens, importsObj, parentNode) {
    let childNodes = {};
    let props = {};
    let token;
    for (let i = 0; i < astTokens.length; i++) {
      // Case for finding JSX tags eg <App .../>
      if (
        astTokens[i].type.label === "jsxTagStart" &&
        astTokens[i + 1].type.label === "jsxName"
      ) {
        if (importsObj[astTokens[i + 1].value]) {
          const componentName = astTokens[i + 1].value;

          token = astTokens[i + 1];

          // properly get the ast of the parent node
          const jsxFilePath = parentNode.filePath;
          const jsxCode = fs.readFileSync(jsxFilePath, "utf8");
          const parent_ast = swc.parseSync(jsxCode, {
            syntax: "typescript",
            tsx: true,
          });

          // initialize a tree
          let tree = new NaryTree();

          // fill in the root of the tree
          let paramArray = [];
          traverse(
            parent_ast,
            findParameterNamesMainComponent(parentNode.name, paramArray, tree)
          );

          // initialize restOperatorMap

          let restOperatorMap = new Map();

          // fill in the restOperatorMap
          const passedProps = Object.keys(parentNode.props);
          if (tree.getRootNode()) {
            traverse(
              parent_ast,
              getRestOperatorMaps(
                restOperatorMap,
                parentNode.name,
                tree,
                passedProps
              )
            );
          }

          props = this.getJSXProps(astTokens, i + 2, restOperatorMap);
          childNodes = this.getChildNodes(
            importsObj,
            token,
            props,
            parentNode,
            childNodes
          );
        } else {
          const componentName = astTokens[i + 1].value;

          // generate ast
          const jsxFilePath = parentNode.filePath;
          const jsxCode = fs.readFileSync(jsxFilePath, "utf8");
          const ast = swc.parseSync(jsxCode, {
            syntax: "typescript",
            tsx: true,
          });
          /*
                     HOC HANDLING
                     we know the renamed version of the component name
                     now need to find the name of the actualComponentName
                    */
          let actualComponent = [];
          traverse(ast, getActualComponent(componentName, actualComponent));
          const originalComponent = actualComponent.shift();

          if (importsObj[originalComponent]) {
            token = { value: originalComponent };

            // get the ast of the parent node
            const jsxFilePath = parentNode.filePath;
            const jsxCode = fs.readFileSync(jsxFilePath, "utf8");
            const parent_ast = swc.parseSync(jsxCode, {
              syntax: "typescript",
              tsx: true,
            });

            // initialize a tree
            let tree = new NaryTree();

            // fill in the root of the tree
            let paramArray = [];
            traverse(
              parent_ast,
              findParameterNamesMainComponent(parentNode.name, paramArray, tree)
            );

            let restOperatorMap = new Map();

            // fill in the restOperatorMap
            const passedProps = Object.keys(parentNode.props);

            if (tree.getRootNode()) {
              traverse(
                parent_ast,
                getRestOperatorMaps(
                  restOperatorMap,
                  parentNode.name,
                  tree,
                  passedProps
                )
              );
            }
            props = this.getJSXProps(astTokens, i + 2, restOperatorMap);

            childNodes = this.getChildNodes(
              importsObj,
              token,
              props,
              parentNode,
              childNodes
            );
          }
        }

        // Case for finding components passed in as props e.g. <Route component={App} />
      } else if (
        astTokens[i].type.label === "jsxName" &&
        (astTokens[i].value === "component" ||
          astTokens[i].value === "children") &&
        importsObj[astTokens[i + 3].value]
      ) {
        token = astTokens[i + 3];
        childNodes = this.getChildNodes(
          importsObj,
          token,
          props,
          parentNode,
          childNodes
        );
      }
    }
    return Object.values(childNodes);
  }

  getChildNodes(imports, astToken, props, parent, children) {
    let actualComponentPath = [];
    getActualComponentPath(
      imports[astToken.value]["importName"],
      parent.filePath,
      imports[astToken.value]["importPath"],
      actualComponentPath
    );
    const absolutePath = actualComponentPath.shift();

    if (children[astToken.value]) {
      children[astToken.value].count += 1;
      children[astToken.value].props = {
        ...children[astToken.value].props,
        ...props,
      };
    } else {
      // Add tree node to childNodes if one does not exist
      children[astToken.value] = {
        id: getNonce(),
        name: imports[astToken.value]["importName"],
        fileName: path.basename(imports[astToken.value]["importPath"]),
        filePath: absolutePath,
        importPath: imports[astToken.value]["importPath"],
        expanded: false,
        depth: parent.depth + 1,
        thirdParty: false,
        reactRouter: false,
        reduxConnect: false,
        count: 1,
        props: props,
        children: [],
        parentList: [parent.filePath].concat(parent.parentList),
        error: "",
      };
    }
    return children;
  }

  // Extracts prop names from a JSX element
  getJSXProps(astTokens, j, restOperatorMap) {
    const props = {};
    while (astTokens[j].type.label !== "jsxTagEnd") {
      if (astTokens[j].type.label === "jsxName") {
        props[astTokens[j].value] = false;
      } else if (
        astTokens[j].type.label === "name" &&
        restOperatorMap.has(astTokens[j].value)
      ) {
        const val = restOperatorMap.get(astTokens[j].value);
        val.forEach((element) => {
          props[element] = false;
        });
      }
      j += 1;
    }
    return props;
  }

  // Checks if current Node is connected to React-Redux Store
  checkForRedux(astTokens, importsObj) {
    // Check that react-redux is imported in this file (and we have a connect method or otherwise)
    let reduxImported = false;
    let connectAlias;
    Object.keys(importsObj).forEach((key) => {
      if (
        importsObj[key].importPath === "react-redux" &&
        importsObj[key].importName === "connect"
      ) {
        reduxImported = true;
        connectAlias = key;
      }
    });
    if (!reduxImported) {
      return false;
    }
    // Check that connect method is invoked and exported in the file
    for (let i = 0; i < astTokens.length; i += 1) {
      if (
        astTokens[i].type.label === "export" &&
        astTokens[i + 1].type.label === "default" &&
        astTokens[i + 2].value === connectAlias
      ) {
        return true;
      }
    }
    return false;
  }
}

module.exports = { Parser };
