const start = performance.now();
const fs = require("fs");
const path = require("path");
const swc = require("@swc/core");
const DisjointSet = require("../classes/DisjointSet");
const { NaryTree } = require("../classes/NaryTree.js");
const {
  appendToJsonFile,
  initializeJsonFile,
} = require("../../utils/jsonUtils.js");
const { getAbsolutePath } = require("../../utils/resolver.js");
const { DIRECTORY } = require("../../constants.js");

const filePath = process.argv[2];
const propsPassed = JSON.parse(process.argv[3]);
const componentName = process.argv[4];
const projectPath = process.argv[5];
const jsonFilePath = process.argv[6];

const jsxFilePath = filePath;

const jsxCode = fs.readFileSync(jsxFilePath, "utf8");

const tree = new NaryTree();

let topLevelUsedProps = [];

// Generate ast
const ast = swc.parseSync(jsxCode, {
  syntax: "typescript",
  tsx: true,
});

const usedProps = [];

// Function to traverse the AST
function traverse(node, visitor) {
  if (!node || typeof node !== "object") return;
  if (Array.isArray(node)) {
    node.forEach((child) => traverse(child, visitor));
  } else {
    if (visitor.enter) visitor.enter(node);
    Object.keys(node).forEach((key) => {
      if (key !== "loc") traverse(node[key], visitor);
    });
    if (visitor.exit) visitor.exit(node);
  }
}

let functionStack = [];
let importedFunctionsMain = [];
let importedNameSpaceSpecifiersMain = [];

// storing those functions which are imported
let importedFunctionNamesSet = new Set();

let ds = new DisjointSet();

function isValidExtension(filename) {
  const extensions = ['.js', '.ts', '.tsx', '.jsx'];
  return extensions.some(ext => filename.endsWith(ext));
}

function processArgument(argument, paramArray, parent) {
  if (argument.type === "ObjectPattern") {
    argument.properties.forEach((element) => {
      // Recurse for nested ObjectPattern
      if (
        element.key?.type === "Identifier" &&
        element.value !== null &&
        element.value?.type === "ObjectPattern"
      ) {
        const par = element.key.value;
        if (tree.checkNode(ds.findUPar(parent)).exists) {
          tree.insert(par, ds.findUPar(parent));
        }
        processArgument(element.value, paramArray, par);
      } else if (
        element.type === "AssignmentPatternProperty" &&
        element.key?.type === "Identifier"
      ) {
        if (tree.checkNode(ds.findUPar(parent)).exists) {
          tree.insert(element.key.value, ds.findUPar(parent));
        }
        paramArray.push(element.key.value);
      } else if (
        element.type === "KeyValuePatternProperty" &&
        element.key?.type === "Identifier"
      ) {
        if (tree.checkNode(ds.findUPar(parent)).exists) {
          tree.insert(element.key.value, ds.findUPar(parent));
        }
        paramArray.push(element.key.value);
        if (element.value?.type === "AssignmentPattern") {
          if (element.value?.left?.type === "Identifier") {
            paramArray.pop();
            paramArray.push(element.value.left.value);
            ds.unionByRank(element.key.value, element.value.left.value);
          }
        } else if (element.value?.type === "Identifier") {
          paramArray.pop();
          paramArray.push(element.value.value);
          ds.unionByRank(element.key.value, element.value.value);
        }
      }
    });
  }
}

function findParameterNamesMainComponent(functionName, paramArray) {
  return {
    // handle the case of arrow functions
    enter(node) {
      if (
        node.type === "VariableDeclarator" &&
        node.id?.type === "Identifier"
      ) {
        if (
          node.id?.value === functionName &&
          node.init?.type === "ArrowFunctionExpression"
        ) {
          let parameters = node.init.params;
          parameters.forEach((argument) => {
            // normal
            if (argument.type === "Identifier") {
              paramArray.push(argument.value);
              tree.insert(argument.value);
            }

            // destructured object pattern
            if (argument.type === "ObjectPattern") {
              tree.insert("props");
              processArgument(argument, paramArray, "props");
            }

            // destructured array pattern
            if (argument.type === "ArrayPattern") {
              tree.insert("props");
              argument.elements.forEach((element) => {
                if (element.type === "Identifier") {
                  tree.insert(element.value, "props");
                  paramArray.push(element.value);
                }
              });
            }
          });
        } else if (
          node.id?.value === functionName &&
          node.init?.type === "CallExpression" &&
          node.init?.arguments[0]?.expression?.type ===
            "ArrowFunctionExpression"
        ) {
          let parameters = node.init.arguments[0].expression.params;
          parameters.forEach((argument) => {
            // normal
            if (argument.type === "Identifier") {
              paramArray.push(argument.value);
              tree.insert(argument.value);
            }

            // destructured object pattern
            if (argument.type === "ObjectPattern") {
              tree.insert("props");
              processArgument(argument, paramArray, "props");
            }

            // destructured array pattern
            if (argument.type === "ArrayPattern") {
              tree.insert("props");
              argument.elements.forEach((element) => {
                if (element.type === "Identifier") {
                  tree.insert(element.value, "props");
                  paramArray.push(element.value);
                }
              });
            }
          });
        }
      }

      // handle the case of normal function declarations
      if (
        (node.type === "FunctionDeclaration" ||
          node.type === "FunctionExpression") &&
        node.identifier?.type === "Identifier" &&
        node.identifier?.value === functionName
      ) {
        node.params.forEach((argument) => {
          if (argument.type === "Parameter") {
            // normal
            if (argument.pat?.type === "Identifier") {
              paramArray.push(argument.pat.value);
              tree.insert(argument.pat.value);
            }

            // destructured object pattern
            else if (argument.pat?.type === "ObjectPattern") {
              tree.insert("props");
              processArgument(argument.pat, paramArray, "props");
            }

            // destructured array pattern
            else if (argument.pat?.type === "ArrayPattern") {
              argument.pat.elements.forEach((element) => {
                if (element.type === "Identifier") {
                  paramArray.push(element.value);
                  tree.insert(element.value, "props");
                }
              });
            }
          }
        });
      }
    },
  };
}

function findParameterNames(functionName, paramArray, argsArray) {
  let argsIdx = 0;
  return {
    // handle the case of function expressions
    enter(node) {
      // handle the case of arrow functions
      if (
        node.type === "VariableDeclarator" &&
        node.id?.type === "Identifier"
      ) {
        if (
          node.id.value === functionName &&
          node.init?.type === "ArrowFunctionExpression"
        ) {
          let parameters = node.init.params;
          parameters.forEach((argument) => {
            // normal
            if (argument.type === "Identifier") {
              paramArray.push(argument.value);
              if (argsArray[argsIdx] != argument.value) {
                ds.unionByRank(argsArray[argsIdx], argument.value);
              }
              argsIdx += 1;
            }

            // destructured object pattern
            if (argument.type === "ObjectPattern") {
              processArgument(argument, paramArray, argsArray[argsIdx]);
              argsIdx += 1;
            }

            // destructured array pattern
            if (argument.type === "ArrayPattern") {
              argument.elements.forEach((element) => {
                if (element.type === "Identifier") {
                  paramArray.push(element.value);
                }
              });
              argsIdx += 1;
            }
          });
        }
      }

      // handle the case of normal function declarations
      else if (
        (node.type === "FunctionDeclaration" ||
          node.type === "FunctionExpression") &&
        node.identifier?.type === "Identifier" &&
        node.identifier?.value === functionName
      ) {
        node.params.forEach((argument) => {
          if (argument.type === "Parameter") {
            // normal
            if (argument.pat?.type === "Identifier") {
              paramArray.push(argument.pat.value);
              if (argument.pat.value !== argsArray[argsIdx]) {
                ds.unionByRank(argsArray[argsIdx], argument.pat.value);
              }
              argsIdx += 1;
            }

            // destructured object pattern
            else if (argument.pat?.type === "ObjectPattern") {
              processArgument(argument.pat, paramArray, argsArray[argsIdx]);
              argsIdx += 1;
            }

            // destructured array pattern
            else if (argument.pat?.type === "ArrayPattern") {
              argument.pat.elements.forEach((element) => {
                if (element.type === "Identifier") {
                  paramArray.push(element.value);
                }
              });
              argsIdx += 1;
            }
          }
        });
      }
    },
  };
}

function markObject(argName) {
  return {
    enter(node) {
      if (node.type === "Identifier" && node.value === argName) {
        if (tree.checkNode(node.value).exists) {
          tree.markVisitedObject(node.value);
        }
      }
    },
  };
}

function visitorObject(argName) {
  return {
    enter(node) {
      let recArray = [];
      if (node.type === "MemberExpression") {
        traverse(node, markObject(argName));
        let parentNode = node;
        let currNode = node;
        while (currNode.object?.type === "MemberExpression") {
          recArray.push(currNode.property.value);
          currNode = currNode.object;
        }
        if (
          currNode.object?.type === "Identifier" &&
          currNode.object?.value === argName
        ) {
          if (!tree.checkNode(parentNode.property.value).exists) {
            tree.insert(parentNode.property.value, argName);
          }
          tree.markVisited(ds.findUPar(parentNode.property.value));
          usedProps.push(`${parentNode.property.value}`);
        }
      } else if (
        node.type === "OptionalChainingExpression" &&
        node.base?.type === "MemberExpression"
      ) {
        traverse(node, markObject(ds.findUPar(argName)));
      }
    },
  };
}

function visitorLeafNodeUpdate(leafMap) {
  return {
    enter(node) {
      if (
        (node.type === "Identifier" || node.type === "JSXText") &&
        leafMap.has(node.value)
      ) {
        const val = leafMap.get(node.value);
        leafMap.set(node.value, val + 1);
      }
    },
  };
}

function leafNodeMark(leafMap) {
  for (const [key, value] of leafMap) {
    if (value >= 1) {
      tree.markVisited(ds.findUPar(key));
      usedProps.push(`${key}`);
    }
  }
}

const hooks = new Set([
  "useState",
  "useEffect",
  "useContext",
  "useReducer",
  "useCallback",
  "useMemo",
  "useRef",
  "useImperativeHandle",
  "useLayoutEffect",
  "useDebugValue",
  "log",
  "shape",
  "require",
  "react",
]);

// contains mapping from src imported file to its default export if any
const helperFileDefaultFunctions = new Map();

// map to store imported objects src (in case of import * as <identifier>)
let namespacetoPathMap = new Map();

let actualImportMap = new Map();

const findDefaultExportHelper = (absolutePath) => {
  return {
    enter(node) {
      if (node.type === "ExportDefaultDeclaration") {
        if (
          node.decl?.type === "FunctionExpression" &&
          node.decl?.identifier?.type === "Identifier"
        ) {
          helperFileDefaultFunctions.set(
            absolutePath,
            node.decl.identifier.value
          );
        }
      }
      if (node.type === "ExportDefaultExpression") {
        if (node.expression?.type === "Identifier") {
          helperFileDefaultFunctions.set(absolutePath, node.expression.value);
        }
      }
    },
  };
};

const findDefaultExport = (filePath) => {
  const jsxFilePath = filePath;
  const jsxCode = fs.readFileSync(jsxFilePath, "utf8");
  const helperFunctionAST = swc.parseSync(jsxCode, {
    syntax: "typescript",
    tsx: true,
  });
  traverse(helperFunctionAST, findDefaultExportHelper(filePath));
};

function findImportedFunctions(
  importedFunctions,
  importedNameSpaceSpecifiers,
  currFileAbsolutePath
) {
  return {
    enter(node) {
      if (node.type === "ImportDeclaration") {
        node.specifiers.forEach((element) => {
          if (
            element.local?.type === "Identifier" &&
            !hooks.has(element.local.value)
          ) {
            if (element.type === "ImportSpecifier") {
              if (element.imported?.value === "default") {
                importedFunctions.push({
                  functionName: element.local.value,
                  src: node.source.value,
                  default: true,
                });
                importedFunctionNamesSet.add(element.local.value);
                const absolutePath = resolvePath(
                  currFileAbsolutePath,
                  node.source.value
                );
                if (!absolutePath.includes("node_modules") && isValidExtension(absolutePath))
                  findDefaultExport(absolutePath);
              } else if (element.imported !== null) {
                importedFunctions.push({
                  functionName: element.local.value,
                  src: node.source.value,
                  default: false,
                });
                importedFunctionNamesSet.add(element.local.value);
                actualImportMap.set(
                  element.local.value,
                  element.imported.value
                );
              } else {
                importedFunctions.push({
                  functionName: element.local.value,
                  src: node.source.value,
                  default: false,
                });
                importedFunctionNamesSet.add(element.local.value);
              }
            } else if (element.type === "ImportDefaultSpecifier") {
              const absolutePath = resolvePath(
                currFileAbsolutePath,
                node.source.value
              );
              if (!absolutePath.includes("node_modules") && isValidExtension(absolutePath))
                findDefaultExport(absolutePath);
              importedFunctions.push({
                functionName: element.local.value,
                src: node.source.value,
                default: true,
              });
              importedFunctionNamesSet.add(element.local.value);
            } else if (element.type === "ImportNamespaceSpecifier") {
              importedNameSpaceSpecifiers.push(element.local.value);
              namespacetoPathMap.set(element.local.value, node.source.value);
            }
          }
        });
      } else if (
        node.type === "VariableDeclarator" &&
        node.init?.type === "CallExpression" &&
        node.init?.callee?.value === "require"
      ) {
        const importedPath = node.init.arguments[0].expression.value;
        if (node.id?.type === "ObjectPattern") {
          node.id.properties.forEach((element) => {
            if (element.type === "AssignmentPatternProperty") {
              if (element.key.type === "Identifier") {
                importedFunctions.push({
                  functionName: element.key.value,
                  src: importedPath,
                  default: false,
                });
                importedFunctionNamesSet.add(element.key.value);
              }
            }
          });
        } else if (node.id?.type === "Identifier") {
          importedFunctions.push({
            functionName: node.id.value,
            src: importedPath,
            default: false,
          });
          importedFunctionNamesSet.add(node.id.value);
        }
      }
    },
  };
}

function updateMap(value, map) {
  if (map.has(value)) {
    let val = map.get(value);
    map.set(value, val - 1);
  } else {
    map.set(value, -1);
  }
}

markPropsVisited = {
  enter(node) {
    if (
      node.type === "Identifier" &&
      tree.checkNode(ds.findUPar(node.value)).exists
    ) {
      tree.markVisitedObject(node.value);
    }
  },
};

// to build function stack
function functionCallVisitor(map, functionStack) {
  return {
    enter(node) {
      if (node.type === "CallExpression") {
        let functionName;
        let functionObject = "none";

        if (node.callee?.type === "Identifier") {
          functionName = node.callee.value;
        } else if (node.callee?.type === "MemberExpression") {
          functionName = node.callee.property.value;
          functionObject = node.callee.object.value;
        } else {
          functionName = "anonymous";
        }

        if (node.callee?.type === "MemberExpression") {
          if (node.callee.property.type === "Identifier") {
            functionName = node.callee.property.value;
          }
        }
        if (!hooks.has(functionName)) {
          argsArray = [];
          node.arguments.forEach((arg) => {
            if (arg.expression?.type === "StringLiteral") {
              argsArray.push(arg.expression.value);
              updateMap(arg.expression.value, map);
            } else if (arg.expression?.type === "NumericLiteral") {
              argsArray.push(arg.expression.value);
              updateMap(arg.expression.value, map);
            } else if (arg.expression?.type === "Identifier") {
              argsArray.push(arg.expression.value);
              updateMap(arg.expression.value, map);
            } else if (arg.expression?.type === "ObjectExpression") {
              arg.expression.properties.forEach((element) => {
                traverse(element, markPropsVisited);
              });
              argsArray.push("obj");
            } else if (arg.expression?.type === "MemberExpression") {
              argsArray.push(arg.expression.property.value);
              updateMap(arg.expression.property.value, map);
            }
          });
          if (functionObject !== "none")
            importedFunctionNamesSet.add(functionName);
          functionStack.push({
            functionName,
            arguments: argsArray,
            functionObject,
          });
        }
      }
    },
  };
}

function processDestructuredInstances(argument, destructuredMap, localMap) {
  if (argument.type === "ObjectPattern") {
    argument.properties.forEach((variable) => {
      if (
        variable.type === "KeyValuePatternProperty" &&
        variable.value !== null &&
        variable.value?.type === "ObjectPattern"
      ) {
        processDestructuredInstances(variable.value, destructuredMap, localMap);
      } else if (
        variable.type === "AssignmentPatternProperty" &&
        variable.key?.type === "Identifier"
      ) {
        destructuredMap.set(
          variable.key.value,
          localMap.get(variable.key.value)
        );
      } else if (
        variable.type === "KeyValuePatternProperty" &&
        variable.key?.type === "Identifier" &&
        variable.value?.type === "Identifier"
      ) {
        if (!destructuredMap.has(variable.value.value)) {
          destructuredMap.set(
            variable.value.value,
            localMap.get(variable.value.value)
          );
        }
      }
    });
  }
}

function findDestructuredInstances(destructuredMap, localMap) {
  return {
    enter(node) {
      if (node.type === "VariableDeclaration") {
        node.declarations.forEach((element) => {
          if (element.type === "VariableDeclarator") {
            if (element.id?.type === "ObjectPattern") {
              processDestructuredInstances(
                element.id,
                destructuredMap,
                localMap
              );
            } else if (
              element.init?.type === "Identifier" &&
              element.id?.type === "Identifier"
            ) {
              destructuredMap.set(
                element.id.value,
                localMap.get(element.id.value)
              );
            }
          }
        });
      }
    },
  };
}

function processObjectDeclaration(argument, localMap, parent) {
  if (argument.type === "ObjectPattern") {
    argument.properties.forEach((variable) => {
      // Recurse for nested ObjectPattern
      if (
        variable.type === "KeyValuePatternProperty" &&
        variable.value !== null &&
        variable.value?.type === "ObjectPattern"
      ) {
        const par = variable.key.value;
        if (tree.checkNode(ds.findUPar(parent)).exists) {
          tree.insert(par, ds.findUPar(parent));
        }
        processObjectDeclaration(variable.value, localMap, par);
      } else if (
        variable.type === "AssignmentPatternProperty" &&
        variable.key?.type === "Identifier"
      ) {
        //update tree
        if (tree.checkNode(ds.findUPar(parent)).exists) {
          tree.insert(variable.key.value, ds.findUPar(parent));
        }
        updateMap(variable.key.value, localMap);
      } else if (
        variable.type === "KeyValuePatternProperty" &&
        variable.key?.type === "Identifier" &&
        variable.value?.type === "Identifier"
      ) {
        if (tree.checkNode(ds.findUPar(parent)).exists) {
          tree.insert(variable.key.value, ds.findUPar(parent));
        }
        if (variable.key.value != variable.value.value) {
          ds.unionByRank(variable.key.value, variable.value.value);
        }
        updateMap(variable.key.value, localMap);
        updateMap(variable.value.value, localMap);
      }
    });
  }
}

function handleVarDeclarations(localMap) {
  return {
    enter(node) {
      if (node.type === "VariableDeclaration") {
        node.declarations.forEach((element) => {
          if (element.type === "VariableDeclarator") {
            const par = element.init?.value;

            if (element.id?.type === "ObjectPattern") {
              processObjectDeclaration(element.id, localMap, par);
            } else if (
              element.init?.type === "Identifier" &&
              element.id?.type === "Identifier"
            ) {
              ds.unionByRank(element.init?.value, element.id?.value);
              updateMap(element.id?.value, localMap);
              updateMap(element.init?.value, localMap);
            }
          }
        });
      }
    },
  };
}

let functionBodyNode;
function getFunctionBodyNode(functionName) {
  return {
    enter(node) {
      if (
        node.type === "VariableDeclarator" &&
        node.id?.type === "Identifier" &&
        node.id?.value === functionName
      ) {
        if (node.init?.type === "ArrowFunctionExpression") {
          functionBodyNode = node.init.body;
        }
        if (
          node.init?.type === "CallExpression" &&
          node.init?.arguments[0]?.expression?.type ===
            "ArrowFunctionExpression"
        ) {
          functionBodyNode = node.init?.arguments[0]?.expression.body;
        }
      } else if (
        (node.type === "FunctionDeclaration" ||
          node.type === "FunctionExpression") &&
        node.identifier?.type === "Identifier" &&
        node.identifier?.value === functionName
      ) {
        functionBodyNode = node.body;
      }
    },
  };
}

function resolvePath(currFileAbsolutePath, relativeImportPath) {
  const absoluteFilePath = getAbsolutePath(
    DIRECTORY,
    currFileAbsolutePath,
    relativeImportPath
  );
  return absoluteFilePath;
}

function handleNameModuleImports(functionName, functionStack) {
  functionStack.forEach((element) => {
    if (element.functionName === functionName) {
      const arguments = element.arguments;
      arguments.forEach((arg) => {
        if (tree.checkNode(ds.findUPar(arg)).isLeaf) {
          tree.markVisited(ds.findUPar(arg));
        } else if (tree.checkNode(ds.findUPar(arg)).isObject) {
          tree.markVisitedObject(ds.findUPar(arg));
        }
      });
    }
  });
}

let restOperatorMap = new Map();

function getRestOperatorMaps(map, functionName, isClass) {
  return {
    enter(node) {
      if (
        node.type === "VariableDeclarator" &&
        node.id?.type === "ObjectPattern" &&
        node.init?.type === "Identifier" &&
        ((tree.getRootNode() &&
          node.init?.value === tree.getRootNode().value) ||
          (isClass && node.init?.value === "props"))
      ) {
        let key = "none";

        let currDestructuredProps = new Set();
        const properties = node.id.properties;
        properties.forEach((arg) => {
          if (
            arg.type === "RestElement" &&
            arg.argument?.type === "Identifier"
          ) {
            key = arg.argument?.value;
          } else if (
            (arg.type === "KeyValuePatternProperty" ||
              arg.type === "AssignmentPatternProperty") &&
            arg.key?.type === "Identifier"
          ) {
            currDestructuredProps.add(arg.key?.value);
          }
        });

        if (key !== "none") {
          const difference = propsPassed.filter(
            (prop) => !currDestructuredProps.has(prop)
          );
          map.set(key, difference);
        }
      } else if (
        node.type === "VariableDeclarator" &&
        node.id?.type === "Identifier"
      ) {
        if (
          node.id?.value === functionName &&
          node.init?.type === "ArrowFunctionExpression"
        ) {
          let parameters = node.init.params;
          let key = "none";
          let currDestructuredProps = new Set();

          if (parameters[0].type === "ObjectPattern") {
            parameters[0].properties.forEach((arg) => {
              if (
                arg.type === "RestElement" &&
                arg.argument?.type === "Identifier"
              ) {
                key = arg.argument?.value;
              } else if (
                (arg.type === "KeyValuePatternProperty" ||
                  arg.type === "AssignmentPatternProperty") &&
                arg.key?.type === "Identifier"
              ) {
                currDestructuredProps.add(arg.key?.value);
              }
            });
            if (key !== "none") {
              const difference = propsPassed.filter(
                (prop) => !currDestructuredProps.has(prop)
              );
              map.set(key, difference);
            }
          }
        } else if (
          node.id?.value === functionName &&
          node.init?.type === "CallExpression" &&
          node.init?.arguments[0]?.expression?.type ===
            "ArrowFunctionExpression"
        ) {
          let key = "none";
          let currDestructuredProps = new Set();
          let parameters = node.init.arguments[0].expression.params;
          if (parameters[0].type === "ObjectPattern") {
            parameters[0].properties.forEach((arg) => {
              if (
                arg.type === "RestElement" &&
                arg.argument?.type === "Identifier"
              ) {
                key = arg.argument?.value;
              } else if (
                (arg.type === "KeyValuePatternProperty" ||
                  arg.type === "AssignmentPatternProperty") &&
                arg.key?.type === "Identifier"
              ) {
                currDestructuredProps.add(arg.key?.value);
              }
            });
            if (key !== "none") {
              const difference = propsPassed.filter(
                (prop) => !currDestructuredProps.has(prop)
              );
              map.set(key, difference);
              map.set(key, difference);
            }
          }
        }
      }

      // handle the case of normal function declarations
      if (
        (node.type === "FunctionDeclaration" ||
          node.type === "FunctionExpression") &&
        node.identifier?.type === "Identifier" &&
        node.identifier?.value === functionName
      ) {
        if (node.params[0].pat.type === "ObjectPattern") {
          let key = "none";
          let currDestructuredProps = new Set();
          const properties = node.params[0].pat.properties;
          properties.forEach((arg) => {
            if (
              arg.type === "RestElement" &&
              arg.argument?.type === "Identifier"
            ) {
              key = arg.argument?.value;
            } else if (
              (arg.type === "KeyValuePatternProperty" ||
                arg.type === "AssignmentPatternProperty") &&
              arg.key?.type === "Identifier"
            ) {
              currDestructuredProps.add(arg.key?.value);
            }
          });
          if (key !== "none") {
            const difference = propsPassed.filter(
              (prop) => !currDestructuredProps.has(prop)
            );
            map.set(key, difference);
            map.set(key, difference);
          }
        }
      }
    },
  };
}

function processFunction(
  helperFunctionStack,
  helperFunctionAST,
  functionContext
) {
  const { functionName, arguments, functionObject } = functionContext;

  functionBodyNode = "null";
  traverse(helperFunctionAST, getFunctionBodyNode(functionName));

  const functionBodyAST = functionBodyNode;

  if (functionBodyAST !== "null") {
    if (functionObject === "none") {
      let paramArray = [];
      traverse(
        helperFunctionAST,
        findParameterNames(functionName, paramArray, arguments)
      );

      let localMap = new Map();

      traverse(
        functionBodyAST,
        functionCallVisitor(localMap, helperFunctionStack)
      );
      helperFunctionStack = helperFunctionStack.filter(
        (element) => element.functionName !== "anonymous"
      );

      traverse(functionBodyAST, handleVarDeclarations(localMap));

      let leafMap = new Map();

      paramArray.forEach((param) => {
        if (tree.checkNode(ds.findUPar(param)).isLeaf) {
          if (localMap.has(param)) leafMap.set(param, localMap.get(param));
          else leafMap.set(param, 0);
        } else if (tree.checkNode(ds.findUPar(param)).isObject) {
          traverse(functionBodyAST, visitorObject(param));
        }
      });

      traverse(functionBodyAST, visitorLeafNodeUpdate(leafMap));

      leafNodeMark(leafMap);

      // finally have to handle destructured arguments within the functionBodyAST as well

      // HANDLE DESTRUCTURED INSTANCES

      let destructuredMap = new Map();
      let destructuredleafMap = new Map();

      traverse(
        functionBodyAST,
        findDestructuredInstances(destructuredMap, localMap)
      );

      for (const [key, value] of destructuredMap) {
        if (
          tree.checkNode(ds.findUPar(key)).isLeaf &&
          ds.findUPar(key) !== rootNodeVal
        ) {
          destructuredleafMap.set(key, value);
        } else if (
          tree.checkNode(ds.findUPar(key)).isObject ||
          ds.findUPar(key) === rootNodeVal
        ) {
          traverse(functionBodyAST, visitorObject(key));
        }
      }

      traverse(functionBodyAST, visitorLeafNodeUpdate(destructuredleafMap));
      leafNodeMark(destructuredleafMap);
    }
    // handle objects not belonging to namespace specifiers
    else if (
      !namespacetoPathMap.has(functionObject) &&
      functionObject !== "none"
    ) {
      arguments.forEach((arg) => {
        if (tree.checkNode(ds.findUPar(arg)).isLeaf) {
          tree.markVisited(ds.findUPar(arg));
        } else if (tree.checkNode(ds.findUPar(arg)).isObject) {
          tree.markVisitedObject(ds.findUPar(arg));
        }
      });
    }
  } else {
    arguments.forEach((arg) => {
      if (tree.checkNode(ds.findUPar(arg)).isLeaf) {
        tree.markVisited(ds.findUPar(arg));
      } else if (tree.checkNode(ds.findUPar(arg)).isObject) {
        tree.markVisitedObject(ds.findUPar(arg));
      }
    });
  }
}

function handleClassComponents(destructuredSet) {
  return {
    enter(node) {
      if (
        node.type === "VariableDeclarator" &&
        node.id?.type === "ObjectPattern"
      ) {
        if (
          (node.init?.type === "MemberExpression" &&
            node.init?.object?.type === "ThisExpression" &&
            node.init?.property?.type === "Identifier" &&
            node.init?.property?.value === "props") ||
          (node.init?.type === "Identifier" && node.init?.value === "props")
        ) {
          const properties = node.id.properties;
          properties.forEach((arg) => {
            if (
              arg.type === "AssignmentPatternProperty" &&
              arg.key?.type === "Identifier"
            ) {
              destructuredSet.add(arg.key?.value);
            } else if (
              arg.type === "KeyValuePatternProperty" &&
              arg.key?.type === "Identifier"
            ) {
              destructuredSet.add(arg.key?.value);
            }
          });
        }
      }
    },
  };
}

function handleHelperFunctions(
  importedFunctions,
  importedFunctionStack,
  currFileAbsolutePath
) {
  if (importedFunctions.length === 0) return;

  importedFunctions.forEach((functionContext) => {
    const { functionName, src } = functionContext;

    const absolutePath = resolvePath(currFileAbsolutePath, src);

    //check if function is imported from node_modules
    if (absolutePath.includes("node_modules")) {
      handleNameModuleImports(functionName, importedFunctionStack);
    } else {
      const jsxFilePath = absolutePath;

      let helperFunctionAST;
      try {
          const jsxCode = fs.readFileSync(jsxFilePath, 'utf8');
          helperFunctionAST = swc.parseSync(jsxCode, {
              syntax: 'typescript',
              tsx: true,
          });
      }
      catch (error) {
          console.log(`not a [.js,.ts,.jsx,.tsx] file`);
      }

      if (helperFunctionAST) {
      const helperImportedFunctions = [];
      const helperNameSpaceSpecifiers = [];

      const helperImportedFunctionStack = [];

      traverse(
        helperFunctionAST,
        findImportedFunctions(
          helperImportedFunctions,
          helperNameSpaceSpecifiers,
          absolutePath
        )
      );

      importedFunctionStack.forEach((element) => {
        if (element.functionName === functionName) {
          const arguments = element.arguments;

          if (functionContext.default) {
            traverse(
              helperFunctionAST,
              getFunctionBodyNode(helperFileDefaultFunctions.get(absolutePath))
            );
          } else if (actualImportMap.has(functionName)) {
            traverse(
              helperFunctionAST,
              getFunctionBodyNode(actualImportMap.get(functionName))
            );
          } else {
            traverse(helperFunctionAST, getFunctionBodyNode(functionName));
          }

          const functionBodyAST = functionBodyNode;

          let paramArray = [];

          if (functionContext.default) {
            traverse(
              helperFunctionAST,
              findParameterNames(
                helperFileDefaultFunctions.get(absolutePath),
                paramArray,
                arguments
              )
            );
          } else if (actualImportMap.has(functionName)) {
            traverse(
              helperFunctionAST,
              getFunctionBodyNode(actualImportMap.get(functionName))
            );
          } else {
            traverse(helperFunctionAST, getFunctionBodyNode(functionName));
          }

          let helperFunctionStack = [];
          let localMap = new Map();

          traverse(
            functionBodyAST,
            functionCallVisitor(localMap, helperFunctionStack)
          );
          helperFunctionStack = helperFunctionStack.filter(
            (element) => element.functionName !== "anonymous"
          );

          traverse(functionBodyAST, handleVarDeclarations(localMap));

          let leafMap = new Map();

          paramArray.forEach((param) => {
            if (tree.checkNode(ds.findUPar(param)).isLeaf) {
              if (localMap.has(param)) leafMap.set(param, localMap.get(param));
              else leafMap.set(param, 0);
            } else if (tree.checkNode(ds.findUPar(param)).isObject) {
              traverse(functionBodyAST, visitorObject(param));
            }
          });

          traverse(functionBodyAST, visitorLeafNodeUpdate(leafMap));

          leafNodeMark(leafMap);

          // handle deinstances

          let destructuredMap = new Map();
          let destructuredleafMap = new Map();

          traverse(
            functionBodyAST,
            findDestructuredInstances(destructuredMap, localMap)
          );

          for (const [key, value] of destructuredMap) {
            if (
              tree.checkNode(ds.findUPar(key)).isLeaf &&
              ds.findUPar(key) !== rootNodeVal
            ) {
              destructuredleafMap.set(key, value);
            } else if (
              tree.checkNode(ds.findUPar(key)).isObject ||
              ds.findUPar(key) === rootNodeVal
            ) {
              traverse(functionBodyAST, visitorObject(key));
            }
          }

          traverse(functionBodyAST, visitorLeafNodeUpdate(destructuredleafMap));
          leafNodeMark(destructuredleafMap);

          // start working on helperFunctionStack

          while (helperFunctionStack.length > 0) {
            const functionContext = helperFunctionStack.shift();
            const { functionName, arguments, functionObject } = functionContext;
            if (
              importedFunctionNamesSet.has(functionName) ||
              namespacetoPathMap.has(functionObject)
            ) {
              helperImportedFunctionStack.push(functionContext);
            } else {
              processFunction(
                helperFunctionStack,
                helperFunctionAST,
                functionContext
              );
            }
          }
          if (helperImportedFunctions.length > 0) {
            handleHelperFunctions(
              helperImportedFunctions,
              helperImportedFunctionStack,
              absolutePath
            );
          }

          if (helperNameSpaceSpecifiers.length > 0) {
            handleNamespaceImports(
              helperNameSpaceSpecifiers,
              helperImportedFunctionStack,
              absolutePath
            );
          }
        }
      });
    }
  }
  });
}

function handleNamespaceImports(
  importedNameSpaceSpecifiers,
  importedFunctionStack,
  currFileAbsolutePath
) {
  importedNameSpaceSpecifiers.forEach((specifier) => {
    importedFunctionStack.forEach((functionContext) => {
      if (functionContext.functionObject === specifier) {
        const functionObject = functionContext.functionObject;
        const functionName = functionContext.functionName;

        if (namespacetoPathMap.has(functionObject)) {
          const arguments = functionContext.arguments;
          const src = namespacetoPathMap.get(functionObject);

          const absolutePath = resolvePath(currFileAbsolutePath, src);

          if (absolutePath.includes("node_modules")) {
            handleNameModuleImports(functionName, importedFunctionStack);
          } else {
            const jsxFilePath = absolutePath;

            let helperFunctionAST;
            try {
                const jsxCode = fs.readFileSync(jsxFilePath, 'utf8');
                helperFunctionAST = swc.parseSync(jsxCode, {
                    syntax: 'typescript',
                    tsx: true,
                });
            }  
            catch(error) {
                console.log(`not a [.js,.ts,.jsx,.tsx] file`);
            } 

            if (helperFunctionAST) {


            const helperImportedFunctions = [];
            const helperNameSpaceSpecifiers = [];
            const helperImportedFunctionStack = [];

            let helperFunctionStack = [];

            traverse(
              helperFunctionAST,
              findImportedFunctions(
                helperImportedFunctions,
                helperNameSpaceSpecifiers,
                absolutePath
              )
            );

            if (actualImportMap.has(functionName)) {
              traverse(
                helperFunctionAST,
                getFunctionBodyNode(actualImportMap.get(functionName))
              );
            } else {
              traverse(helperFunctionAST, getFunctionBodyNode(functionName));
            }

            const functionBodyAST = functionBodyNode;

            let paramArray = [];

            if (actualImportMap.has(functionName)) {
              traverse(
                helperFunctionAST,
                findParameterNames(
                  actualImportMap.get(functionName),
                  paramArray,
                  arguments
                )
              );
            } else {
              traverse(
                helperFunctionAST,
                findParameterNames(functionName, paramArray, arguments)
              );
            }
            let localMap = new Map();

            traverse(
              functionBodyAST,
              functionCallVisitor(localMap, helperFunctionStack)
            );
            helperFunctionStack = helperFunctionStack.filter(
              (element) => element.functionName !== "anonymous"
            );

            traverse(functionBodyAST, handleVarDeclarations(localMap));

            let leafMap = new Map();

            paramArray.forEach((param) => {
              if (tree.checkNode(ds.findUPar(param)).isLeaf) {
                if (localMap.has(param))
                  leafMap.set(param, localMap.get(param));
                else leafMap.set(param, 0);
              } else if (tree.checkNode(ds.findUPar(param)).isObject) {
                traverse(functionBodyAST, visitorObject(param));
              }
            });

            traverse(functionBodyAST, visitorLeafNodeUpdate(leafMap));

            leafNodeMark(leafMap);

            // handle deinstances

            let destructuredMap = new Map();
            let destructuredleafMap = new Map();

            traverse(
              functionBodyAST,
              findDestructuredInstances(destructuredMap, localMap)
            );

            for (const [key, value] of destructuredMap) {
              if (
                tree.checkNode(ds.findUPar(key)).isLeaf &&
                ds.findUPar(key) !== rootNodeVal
              ) {
                destructuredleafMap.set(key, value);
              } else if (
                tree.checkNode(ds.findUPar(key)).isObject ||
                ds.findUPar(key) === rootNodeVal
              ) {
                traverse(functionBodyAST, visitorObject(key));
              }
            }

            traverse(
              functionBodyAST,
              visitorLeafNodeUpdate(destructuredleafMap)
            );
            leafNodeMark(destructuredleafMap);

            while (helperFunctionStack.length > 0) {
              const functionContext = helperFunctionStack.shift();
              const { functionName, arguments, functionObject } =
                functionContext;
              if (
                importedFunctionNamesSet.has(functionName) ||
                namespacetoPathMap.has(functionObject)
              ) {
                helperImportedFunctionStack.push(functionContext);
              } else {
                processFunction(
                  helperFunctionStack,
                  helperFunctionAST,
                  functionContext
                );
              }
            }

            if (helperImportedFunctions.length > 0) {
              handleHelperFunctions(
                helperImportedFunctions,
                helperImportedFunctionStack,
                absolutePath
              );
            }

            if (helperNameSpaceSpecifiers.length > 0) {
              handleNamespaceImports(
                helperNameSpaceSpecifiers,
                helperImportedFunctionStack,
                absolutePath
              );
            }
          }
        }
        } else {
          handleNameModuleImports(functionName, importedFunctionStack);
        }
      }
    });
  });
}
// check in JSX expression tags also if are using any rest operators, if we are add
// them to the usesProps as well

const arrayDifference = (arr1, arr2) => {
  const set2 = new Set(arr2);
  return arr1.filter((item) => !set2.has(item));
};

function spreadElementBody(restOperatorMap, topLevelUsedProps) {
  return {
    enter(node) {
      if (node.type === "Identifier" && restOperatorMap.has(node.value)) {
        const values = restOperatorMap.get(node.value);
        topLevelUsedProps.push(...values);
      }
    },
  };
}

function markRestOperatorsHelper(restOperatorMap, topLevelUsedProps) {
  return {
    enter(node) {
      if (node.type === "SpreadElement") {
        traverse(node, spreadElementBody(restOperatorMap, topLevelUsedProps));
      }
    },
  };
}

function markRestOperators(restOperatorMap, topLevelUsedProps) {
  return {
    enter(node) {
      if (node.type === "JSXElement") {
        traverse(
          node,
          markRestOperatorsHelper(restOperatorMap, topLevelUsedProps)
        );
      }
    },
  };
}

traverse(
  ast,
  findImportedFunctions(
    importedFunctionsMain,
    importedNameSpaceSpecifiersMain,
    filePath
  )
);

let mainComponentParameters = [];
traverse(
  ast,
  findParameterNamesMainComponent(componentName, mainComponentParameters)
);

traverse(ast, getFunctionBodyNode(componentName));
const functionBodyAST = functionBodyNode;

let localMap = new Map();
traverse(functionBodyAST, functionCallVisitor(localMap, functionStack));

functionStack = functionStack.filter(
  (element) => element.functionName !== "anonymous"
);

traverse(functionBodyAST, handleVarDeclarations(localMap));

let leafMap = new Map();
let rootNodeVal;
try {
  rootNodeVal = tree.getRootNode().value;
} catch (error) {
  try {
    let destructuredSet = new Set();
    traverse(ast, handleClassComponents(destructuredSet));
    let arrayFromSet = [...destructuredSet];
    traverse(ast, getRestOperatorMaps(restOperatorMap, componentName, true));
    restOperatorMap.set("props", propsPassed);
    console.log(`class component`);
    traverse(ast, markRestOperators(restOperatorMap, arrayFromSet));

    arrayFromSet = [...new Set(arrayFromSet)];

    const unusedProps = arrayDifference(propsPassed, arrayFromSet);
    appendToJsonFile(jsonFilePath, {
      componentName: componentName,
      componentFilePath: filePath,
      usedProps: arrayFromSet,
      unusedProps: unusedProps,
    });
    process.exit(0);
  } catch (error) {
    console.log(`neither functional or class component`);
  }
}

mainComponentParameters.forEach((param) => {
  if (
    tree.checkNode(ds.findUPar(param)).isLeaf &&
    ds.findUPar(param) !== rootNodeVal
  ) {
    if (localMap.has(param)) leafMap.set(param, localMap.get(param));
    else leafMap.set(param, 0);
  } else if (
    tree.checkNode(ds.findUPar(param)).isObject ||
    ds.findUPar(param) === rootNodeVal
  ) {
    traverse(functionBodyAST, visitorObject(param));
  }
});
traverse(functionBodyAST, visitorLeafNodeUpdate(leafMap));

leafNodeMark(leafMap);

// handle destructured arguments

let destructuredMap = new Map();
let destructuredleafMap = new Map();

traverse(functionBodyAST, findDestructuredInstances(destructuredMap, localMap));

for (const [key, value] of destructuredMap) {
  if (
    tree.checkNode(ds.findUPar(key)).isLeaf &&
    ds.findUPar(key) !== rootNodeVal
  ) {
    destructuredleafMap.set(key, value);
  } else if (
    tree.checkNode(ds.findUPar(key)).isObject ||
    ds.findUPar(key) === rootNodeVal
  ) {
    traverse(functionBodyAST, visitorObject(key));
  }
}

traverse(functionBodyAST, visitorLeafNodeUpdate(destructuredleafMap));
leafNodeMark(destructuredleafMap);

traverse(ast, getRestOperatorMaps(restOperatorMap, componentName, false));
restOperatorMap.set(tree.getRootNode().value, propsPassed);

traverse(ast, markRestOperators(restOperatorMap, topLevelUsedProps));

let importedFunctionStack = [];

while (functionStack.length > 0) {
  const functionContext = functionStack.shift();
  const { functionName, arguments, functionObject } = functionContext;
  if (
    importedFunctionNamesSet.has(functionName) ||
    namespacetoPathMap.has(functionObject)
  ) {
    importedFunctionStack.push(functionContext);
  } else {
    processFunction(functionStack, ast, functionContext);
  }
}

if (importedFunctionsMain.length > 0) {
  handleHelperFunctions(importedFunctionsMain, importedFunctionStack, filePath);
}

if (importedNameSpaceSpecifiersMain.length > 0) {
  handleNamespaceImports(
    importedNameSpaceSpecifiersMain,
    importedFunctionStack,
    filePath
  );
}
functionStack.forEach((functionContext) => {
  if (
    !namespacetoPathMap.has(functionContext.functionObject) &&
    functionContext.functionObject !== "none"
  ) {
    const arguments = functionContext.arguments;
    arguments.forEach((arg) => {
      if (
        tree.checkNode(ds.findUPar(arg)).isLeaf &&
        ds.findUPar(param) !== rootNodeVal
      ) {
        tree.markVisited(ds.findUPar(arg));
      } else if (
        tree.checkNode(ds.findUPar(arg)).isObject ||
        ds.findUPar(param) === rootNodeVal
      ) {
        tree.markVisitedObject(ds.findUPar(arg));
      }
    });
  }
});

dfs = (node) => {
  if (node === null) {
    return;
  }
  for (let child of node.children) {
    if (child.visited) tree.markParentsAsVisited(child);
    dfs(child);
  }
};
// FINAL TREE PRINTING AFTER DFS
dfs(tree.getRootNode());

tree.print(tree.getRootNode());

const rootNode = tree.getRootNode();

const propsPassedSet = new Set(propsPassed);

if ((rootNode.children.length === 0 && rootNode.visited) || (propsPassed.length === 1 && propsPassed[0] === rootNodeVal && rootNode.visited)) {
  // If the root node has no children, push its value to topLevelUsedProps
  topLevelUsedProps.push(rootNode.value);
} else {
  // If the root node has children, iterate through them
  for (let child of rootNode.children) {
    if (child.visited) {
      topLevelUsedProps.push(child.value);
    }
  }
}

topLevelUsedProps = topLevelUsedProps.filter(prop => prop !== undefined);

console.log(`------------`);
console.log(`printing top level used props:`);
console.log(topLevelUsedProps);
console.log(`------------`);

const unusedProps = arrayDifference(propsPassed, topLevelUsedProps);

console.log(`------------`);
console.log(`printing unused props:`);
console.log(unusedProps);
console.log(`------------`);

appendToJsonFile(jsonFilePath, {
  componentName: componentName,
  componentFilePath: filePath,
  usedProps: topLevelUsedProps,
  unusedProps: unusedProps,
});

const end = performance.now();
console.log(`Time taken: ${end - start} milliseconds`);
