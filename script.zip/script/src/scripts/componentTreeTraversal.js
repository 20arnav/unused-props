const start = performance.now();
const { Parser } = require("./componentTreeParser.js");
const fs = require("fs");
const { spawn } = require("child_process");
const {
  initializeJsonFile,
  removeDuplicatesFromJsonFile,
} = require("../../utils/jsonUtils.js");
const path = require("path");
const {
  PROJECT_DIRECTORY_PATH,
  ENTRY_FILE_PATH,
} = require("../../constants.js");

const rootDir = PROJECT_DIRECTORY_PATH; // absolute path of the project directory
const entryFilePath = ENTRY_FILE_PATH; // root component file path

const parser = new Parser(entryFilePath);
const componentTree = parser.parse();
const componentTreeJson = JSON.stringify(componentTree, null, 2);
const outputFilePath = "./componentTree.json";
const jsonFilePath = "./unused_props_output.json";

initializeJsonFile(jsonFilePath);

function isValidExtension(filename) {
  const extensions = [".js", ".ts", ".tsx", ".jsx"];
  return extensions.some((ext) => filename.endsWith(ext));
}

// Save JSON to a file
fs.writeFileSync(outputFilePath, componentTreeJson, "utf8", (err) => {
  if (err) {
    console.error(
      "An error occurred while saving the component tree to JSON file:",
      err
    );
  } else {
    console.log("Component tree saved to JSON file successfully.");
  }
});

const parsedComponentTree = JSON.parse(componentTreeJson);

let componentMap = new Map();

function dfsToFormComponentMap(node) {
  if (node !== parsedComponentTree) {
    let propNames = new Set(componentMap.get(node.filePath) || []);

    if (Object.keys(node.props).length > 0) {
      Object.keys(node.props).forEach((prop) => propNames.add(prop));
    }

    componentMap.set(node.filePath, Array.from(propNames));
  }

  node.children.forEach((child) => {
    dfsToFormComponentMap(child);
  });
}

dfsToFormComponentMap(parsedComponentTree);

console.log(`Size of component tree is: ${componentMap.size}`);

componentMap.forEach((value, key) => {
  console.log(`${key}: ${JSON.stringify(value, null, 2)}`);
});

function runScript(filePath, propsPassedToComponent, componentName, rootDir) {
  return new Promise((resolve, reject) => {
    const command = "node";
    const args = [
      "./src/scripts/componentScript.js",
      filePath,
      JSON.stringify(propsPassedToComponent),
      componentName,
      rootDir,
      jsonFilePath,
    ];
    const childProcess = spawn(command, args);

    const dir = "output";
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir);
    }

    const outputFilePath = path.join(dir, `${componentName}_output.txt`);
    const outputStream = fs.createWriteStream(outputFilePath);

    childProcess.stdout.on("data", (data) => {
      outputStream.write(data);
    });

    childProcess.stderr.on("data", (data) => {
      outputStream.write(data);
    });

    childProcess.on("close", (code) => {
      outputStream.end();
      if (code !== 0) {
        reject(
          new Error(
            `Script exited with code ${code}. See ${outputFilePath} for details.`
          )
        );
      } else {
        resolve(`Output written to ${outputFilePath}`);
      }
    });

    childProcess.on("error", (error) => {
      outputStream.end();
      reject(new Error(`Error spawning process: ${error.message}`));
    });
  });
}

const visited = new Set();

function collectRunScriptPromises(node, promises) {
  if (visited.has(node.name)) {
    return;
  }

  visited.add(node.name);

  node.children.forEach((child) => {
    collectRunScriptPromises(child, promises);
  });

  const filePath = node.filePath;
  const componentName = node.name;
  const propsPassedToComponent = componentMap.get(filePath) || [];

  if (
    !filePath.includes("node_modules") &&
    node !== parsedComponentTree &&
    propsPassedToComponent.length !== 0 &&
    fs.existsSync(filePath) &&
    isValidExtension(filePath)
  ) {
    promises.push(
      runScript(filePath, propsPassedToComponent, componentName, rootDir)
    );
  }
}

(async () => {
  const promises = [];
  collectRunScriptPromises(parsedComponentTree, promises);
  try {
    const results = await Promise.all(promises);
    results.forEach((result) => console.log(result));
    removeDuplicatesFromJsonFile(jsonFilePath);
  } catch (error) {
    console.error("Error processing components:", error);
  }
})();

const end = performance.now();
console.log(`Time taken: ${end - start} milliseconds`);
