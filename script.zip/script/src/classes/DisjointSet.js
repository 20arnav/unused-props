// UnionFind.js

class DisjointSet {
    constructor() {
        this.parent = {};
        this.rank = {};
    }

    findUPar(name) {
        if (!this.parent[name]) {
            this.parent[name] = name;
            this.rank[name] = 0;
            return name;
        }
        if (this.parent[name] === name) {
            return name;
        }
        return this.parent[name] = this.findUPar(this.parent[name]);
    }

    unionByRank(name1, name2) {
        let root1 = this.findUPar(name1);
        let root2 = this.findUPar(name2);

        if (root1 !== root2) {
            this.parent[root2] = root1;
        }
    }
}

module.exports = DisjointSet;
