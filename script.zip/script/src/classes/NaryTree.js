class Node {
  constructor(value) {
      this.value = value;
      this.children = [];
      this.visited = false; // Boolean to mark the node as visited or not
      this.parent = null; // Reference to the parent node
  }
}

class NaryTree {
  constructor() {
      this.root = null;
  }

  // Method to insert a node in the tree
  insert(newValue, parentValue = null) {
      const newNode = new Node(newValue);
      if (this.root === null) {
          this.root = newNode;
      } else {
          const parentNode = this.findNode(this.root, parentValue);
          if (parentNode) {
              parentNode.children.push(newNode);
              newNode.parent = parentNode;
          } 
      }
  }

  // Helper method to find a node by value
  findNode(node, value) {
      if (node === null) {
          return null;
      }
      if (node.value === value) {
          return node;
      }
      for (let child of node.children) {
          const result = this.findNode(child, value);
          if (result) {
              return result;
          }
      }
      return null;
  }

  // Method to perform a traversal and print the tree
  print(node, indent = " ") {
      if (node !== null && node.parent!==null) {
          console.log(`${indent}Value: ${node.value}, Visited: ${node.visited}, Parent: ${node.parent.value}`);
          for (let child of node.children) {
              this.print(child, indent + "       ");
          }
      }
      else if (node!==null) {
          console.log(`${indent}Value: ${node.value}, Visited: ${node.visited}, Parent: Root`);
          for (let child of node.children) {
              this.print(child, indent + "   ");
          }
      }
  }

  // Method to mark a node as visited by value
  markVisited(value) {
      const node = this.findNode(this.root, value);
      if (node) {
          node.visited = true;
      } else {
          console.log(`Node with value ${value} not found.`);
      }
  }

  // Method to get the root node
  getRootNode() {
      return this.root;
  }


  checkNode(value) {
      const node = this.findNode(this.root, value);
      if (node) {
          const isLeaf = node.children.length === 0;
          return {
              exists: true,
              isObject: !isLeaf,
              isLeaf: isLeaf
          };
      } else {
          return {
              exists: false,
              isObject: false,
              isLeaf: false
          };
      }
  }

  markParentsAsVisited(node) {
      if (node && node.visited && node.parent) {
          node.parent.visited = true;
          this.markParentsAsVisited(node.parent);
      }
  }

  markNodeAndParentsAsVisited(value) {
      const node = this.findNode(this.root, value);
      if (node) {
          node.visited = true;
          this.markParentsAsVisited(node);
      } else {
          console.log(`Node with value ${value} not found.`);
      }
  }

  attachSubtree(subtree, parentValue) {
      const parentNode = this.findNode(this.root, parentValue);
      if (parentNode) {
          if (subtree.root) {
              subtree.root.parent = parentNode;
              parentNode.children.push(subtree.root);
          }
      } else {
          console.log(`Parent node with value ${parentValue} not found.`);
      }
  }

  // Method to mark all children of a node as visited recursively
  markVisitedObject(value) {
      const node = this.findNode(this.root, value);
      if (node) {
          this.recursiveMarkVisited(node);
      } else {
          console.log(`Node with value ${value} not found.`);
      }
  }

  // Helper method to recursively mark all children of a node as visited
  recursiveMarkVisited(node) {
      node.visited = true;
      for (let child of node.children) {
          this.recursiveMarkVisited(child);
      }
  }
}

// Export both classes
module.exports = { Node, NaryTree };


