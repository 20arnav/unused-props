import inquirer from 'inquirer';
import fs from 'fs';
import { execSync } from 'child_process';

const questions = [
  {
    type: 'input',
    name: 'PROJECT_DIRECTORY_PATH',
    message: 'Enter the project directory path:',
  },
  {
    type: 'input',
    name: 'ENTRY_FILE_PATH',
    message: 'Enter the entry file path:',
  },
  {
    type: 'input',
    name: 'WEBPACK_CONFIG_PATH',
    message: 'Enter the webpack config path (optional):',
  },
  {
    type: 'input',
    name: 'TS_CONFIG_PATH',
    message: 'Enter the tsconfig path (optional):',
  },
  {
    type: 'input',
    name: 'LEGACY_LIB_FOLDER_PATH',
    message: 'Enter the legacy lib folder path (optional):',
  },
];

inquirer.prompt(questions).then((answers) => {
  const { PROJECT_DIRECTORY_PATH, ENTRY_FILE_PATH, WEBPACK_CONFIG_PATH, TS_CONFIG_PATH, LEGACY_LIB_FOLDER_PATH } = answers;

  const DIRECTORY = {
    rootFolder: PROJECT_DIRECTORY_PATH,
  };

  if (WEBPACK_CONFIG_PATH) {
    DIRECTORY.webpackConfigPath = WEBPACK_CONFIG_PATH;
  }

  if (TS_CONFIG_PATH) {
    DIRECTORY.tsconfigPath = TS_CONFIG_PATH;
  }

  if (LEGACY_LIB_FOLDER_PATH) {
    DIRECTORY.libFolder = LEGACY_LIB_FOLDER_PATH;
  }

  let content = `
const PROJECT_DIRECTORY_PATH = '${PROJECT_DIRECTORY_PATH}';
const ENTRY_FILE_PATH = '${ENTRY_FILE_PATH}';
const DIRECTORY = {
  rootFolder: PROJECT_DIRECTORY_PATH,
`;

  if (WEBPACK_CONFIG_PATH) {
    content += `  webpackConfigPath: '${WEBPACK_CONFIG_PATH}',\n`;
  }

  if (TS_CONFIG_PATH) {
    content += `  tsconfigPath: '${TS_CONFIG_PATH}',\n`;
  }

  if (LEGACY_LIB_FOLDER_PATH) {
    content += `  libFolder: '${LEGACY_LIB_FOLDER_PATH}',\n`;
  }

  content += `};

module.exports = { PROJECT_DIRECTORY_PATH, ENTRY_FILE_PATH, DIRECTORY };
`;

  fs.writeFileSync('./constants.js', content);

  console.log('Configuration file updated.');
  // Run the componentTreeTraversal script
  execSync('node ./src/scripts/componentTreeTraversal.js', { stdio: 'inherit' });
}).catch((error) => {
  console.error('Error:', error);
});
