const path = require('path');
const fs = require('fs');

//make maps for route to alias;
const resolvers = new Map();
const tsConfigResolver = new Map();
const libToPath = new Map();


//defaults for resolving
const defaultModuleFolder = ['node_modules'];
const defaultMainFiles = ['index'];
const defaultMainFields = ['main'];
const defaultRuntimeFiles = [];
const defaultResolver = {
  resolve: {}
};
const exts = ['.ts','.js','.tsx','.jsx','.json'] 

function makeResolver(directory) {
  // console.log(directory);
  if (directory.webpackConfigPath) {
    try {
      const webpackConfigPath = path.resolve(directory.rootFolder, directory.webpackConfigPath)
      let webpackConfig = require(webpackConfigPath);
      if(webpackConfig.default){
        webpackConfig = webpackConfig.default;
      }
      if (!webpackConfig.resolve) {
        webpackConfig.resolve = {};
      }
      if(webpackConfig.resolve.alias){
        const aliases = Object.keys(webpackConfig.resolve.alias);
        aliases.sort((a, b) => b.length - a.length);
        const sortedObject = {};
        aliases.forEach(key => {
          sortedObject[key] = webpackConfig.resolve.alias[key];
        });
        webpackConfig.resolve.alias = sortedObject;
      }
      if(!webpackConfig.resolve.modules) webpackConfig.resolve.modules = [];
      webpackConfig.resolve.modules = webpackConfig.resolve.modules.concat(findNodeModulesFolders(directory.rootFolder));
      resolvers.set(directory.rootFolder, webpackConfig);
    }
    catch (error) {
      console.log(error);
    }
  }
  else {
    let directoryResolver = defaultResolver;
    if(!directoryResolver.resolve.modules) directoryResolver.resolve.modules = [];
    directoryResolver.resolve.modules = directoryResolver.resolve.modules.concat(findNodeModulesFolders(directory.rootFolder));
    resolvers.set(directory.rootFolder, directoryResolver);
  }
  if (directory.moduleFolders) {
    const directoryResolver = resolvers.get(directory.rootFolder);
    directoryResolver.resolve.modules = directory.moduleFolders;
    resolvers.set(directory.rootFolder, directoryResolver);
  }
  if (!directory.runtimeFiles) directory.runtimeFiles = [];
    const directoryResolver = resolvers.get(directory.rootFolder);
    directoryResolver.resolve.runtimeFiles = directory.runtimeFiles;
    if(directoryResolver.externals) directoryResolver.resolve.runtimeFiles = directoryResolver.resolve.runtimeFiles.concat(Object.keys(directoryResolver.externals));
    resolvers.set(directory.rootFolder, directoryResolver);
  if (directory.tsconfigPath) {
    try {
      const tsConfigPath = path.resolve(directory.rootFolder, directory.tsconfigPath)
      const tsConfig = readTsconfig(tsConfigPath);
      tsConfigResolver.set(directory.rootFolder, tsConfig);
      if(tsConfig.compilerOptions.baseUrl){
        const directoryResolver = resolvers.get(directory.rootFolder);
        directoryResolver.baseUrl = path.resolve(path.dirname(tsConfigPath),tsConfig.compilerOptions.baseUrl);
        resolvers.set(directory.rootFolder, directoryResolver);
      }
    }
    catch (error) {
      console.log("Error in resolving directory ", directory);
      console.log(error);
    }
  }
  // console.log(resolvers.get(directory.rootFolder))
}
  
function findNodeModulesFolders(currentPath) {
  const nodeModulesFolders = [];

  // Define a recursive function to traverse ancestors
  function traverseAncestors(currentDir) {

    const nodeModulesPath = path.join(currentDir, 'node_modules');

    // Check if node_modules folder exists in the current directory
    if (fs.existsSync(nodeModulesPath) && fs.statSync(nodeModulesPath).isDirectory()) {
      nodeModulesFolders.push(nodeModulesPath);
    }

    // Get parent directory
    const parentDir = path.dirname(currentDir);

    // Base case: Stop when parent directory is root (Unix: '/', Windows: 'C:\')
    if (parentDir === currentDir) {
      return;
    }

    // Recursive call to traverse ancestors
    traverseAncestors(parentDir);
  }

  // Start traversing from the provided current path
  traverseAncestors(path.resolve(currentPath));

  return nodeModulesFolders;
}

function tsUnaliasedPath(filepath, contextPath) {
  let myResolver = null;
  for (const [rootdir, resolver] of tsConfigResolver) {
    // Resolve and normalize paths
    const absoluteRootDir = rootdir;
    const absoluteFilePath = contextPath;
    if (absoluteFilePath.startsWith(absoluteRootDir)) {
      myResolver = resolver;
      break;
    }
  }
  if (!myResolver) {
    // console.log(`No resolver found for path ${contextPath}, Please Check if the file is being moved out of scope or Tsconfig`);
    return filepath;
  }
  // Function to check for the longest matching prefix in the alias map
  function findOriginalPrefix(str) {
    for (let obj in myResolver.compilerOptions.paths) {
      let alias = obj;
      let Originalpath = myResolver.compilerOptions.paths[obj][0];
      if (alias.endsWith('*')) alias = alias.slice(0, -1);
      if (Originalpath.endsWith('*')) Originalpath = Originalpath.slice(0, -1);

      if (str.startsWith(alias)) {
        return { alias, Originalpath };
      }
    }
    return null;
  }
  // Recursive function to resolve the full aliased path
  function resolvePath(currentPath) {
    const pathInfo = findOriginalPrefix(currentPath);
    if (pathInfo) {
      const { alias, Originalpath } = pathInfo;
      const restOfPath = currentPath.slice(alias.length);
      return resolvePath(Originalpath + restOfPath);
    }
    return currentPath;
  }

  return resolvePath(filepath);
}

function readTsconfig(absoluteTsconfigPath) {
  // Resolve the absolute path of the tsconfig file

  // Read and parse the tsconfig file
  let tsconfig = JSON.parse(fs.readFileSync(absoluteTsconfigPath, 'utf-8'));
  if (tsconfig.compilerOptions?.paths) {
    for (let obj in tsconfig.compilerOptions.paths) {
      let Originalpath = tsconfig.compilerOptions.paths[obj][0];
      if (Originalpath.startsWith('.')) {
        let absoluteBasePath = path.dirname(absoluteTsconfigPath);
        if(tsconfig.compilerOptions.baseUrl) absoluteBasePath = path.resolve(path.dirname(absoluteTsconfigPath), tsconfig.compilerOptions.baseUrl);
        tsconfig.compilerOptions.paths[obj][0] = path.resolve(absoluteBasePath, Originalpath);
      }
    }
  }
  // If there's an "extends" field, process it
  if (tsconfig.extends) {
    // Resolve the path of the extended tsconfig file
    const extendedTsconfigPath = path.resolve(path.dirname(absoluteTsconfigPath), tsconfig.extends);

    // Recursively read and merge the extended tsconfig
    const extendedTsconfig = readTsconfig(extendedTsconfigPath);

    // Merge extended tsconfig into the current tsconfig
    tsconfig = deepMerge(extendedTsconfig, tsconfig);
  }
  if (tsconfig.compilerOptions?.paths) {

    const aliases = Object.keys(tsconfig.compilerOptions.paths);
    aliases.sort((a, b) => b.length - a.length);
    const sortedObject = {};
    aliases.forEach(key => {
      sortedObject[key] = tsconfig.compilerOptions.paths[key];
    });
    tsconfig.compilerOptions.paths = sortedObject;
  }
  // console.log(tsconfig);
  // Return the current tsconfig if there's no "extends" field
  return tsconfig;
}
function deepMerge(target, source) {
  const output = { ...target };
  for (const key in source) {
    if (Object.prototype.hasOwnProperty.call(source, key)) {
      if (typeof source[key] === 'object' && source[key] !== null && !Array.isArray(source[key])) {
        output[key] = deepMerge(output[key] || {}, source[key]);
      } else {
        output[key] = source[key];
      }
    }
  }
  return output;
}
 
function unaliasedPath(filepath, contextPath) {
  let myResolver = null;
  for (const [rootdir, resolver] of resolvers) {
    // Resolve and normalize paths
    const absoluteRootDir =  rootdir;
    const absoluteFilePath = contextPath;
    // logStatus(absoluteRootDir+"   "+absoluteFilePath +" Result: " +absoluteFilePath.startsWith(absoluteRootDir));
    if (absoluteFilePath.startsWith(absoluteRootDir)) {
      myResolver = resolver;
      break;
    }
  }
  if (!myResolver) {
    // console.log(`No resolver found for path ${contextPath}, assuming no aliases are present`);
    return null;
  }
  if (!myResolver.resolve?.alias) {
    return path.resolve(contextPath,filepath);
  }
  function findOriginalPrefix(str) {
    for (let obj in myResolver.resolve.alias) {
      const alias = obj;
      const path = myResolver.resolve.alias[obj];
      if (str.startsWith(alias)) {
        return { alias, path };
      }
    }
    return null;
  }

  // Recursive function to resolve the full aliased path
  function resolvePath(currentPath) {
    const pathInfo = findOriginalPrefix(currentPath);
    if (pathInfo) {
      const { alias, path } = pathInfo;
      const restOfPath = currentPath.slice(alias.length);
      return resolvePath(path + restOfPath);
    }
    return path.resolve(contextPath, currentPath);
  }

  return resolvePath(filepath);
}

  function moduleResolver(originalImportPath, filePath, contextPath) {
    let newResolver = null;
    let rootDir;
    for (const [rootdir, resolver] of resolvers) {
      // Resolve and normalize paths
      const absoluteRootDir = rootdir;
      const absoluteFilePath = contextPath;
      // logStatus(absoluteRootDir+"   "+absoluteFilePath +" Result: " +absoluteFilePath.startsWith(absoluteRootDir));
      if (absoluteFilePath.startsWith(absoluteRootDir)) {
        rootDir = absoluteRootDir;
        newResolver = resolver;
        break;
      }
    }
    if (!newResolver) {
      console.log(`No resolver found for path ${contextPath}`);
      return null;
    }
      const possibleExtensions = newResolver.resolve?.extensions || exts;
      const possibleMainFiles = newResolver.resolve?.mainFiles || defaultMainFiles;
      const possibleMainFields = newResolver.resolve?.mainFields || defaultMainFields;
      const possibleModulePaths = newResolver.resolve?.modules || defaultModuleFolder;
      const possibleRuntimeFiles = newResolver.resolve?.runtimeFiles || defaultRuntimeFiles;
      const defaultPath = resolvePathInternal(filePath, possibleExtensions, possibleMainFields, possibleMainFiles);
      if (defaultPath) {
        return defaultPath;
      }
      if(newResolver.baseUrl){
        let tsResolvedPath = tsUnaliasedPath(originalImportPath, path.dirname(filePath));
        tsResolvedPath = path.resolve(newResolver.baseUrl,tsResolvedPath);
        const resolvedPath = resolvePathInternal(tsResolvedPath, possibleExtensions, possibleMainFields, possibleMainFiles);
        if(resolvedPath){
          return resolvedPath;
        }
      }
      for (const files of possibleRuntimeFiles) {
        if (path.resolve(rootDir, files) == filePath) {
          runtimeFileHash(filePath);
          return filePath;
        }
        else if(files ==originalImportPath){
          return null;
        }
      }
      for (const moduleDir of possibleModulePaths) {
        let modulePath = path.resolve(rootDir, moduleDir);
        modulePath = path.join(modulePath, originalImportPath);
        const resolvedPath = resolvePathInternal(modulePath, possibleExtensions, possibleMainFields, possibleMainFiles);
        // Step 3: Resolve path
        if (fs.existsSync(modulePath)||resolvedPath) {
          return null;
        }
      }
  
      try{
      if(originalImportPath == require.resolve(originalImportPath)){
      // logStatus(`assuming ${originalImportPath} to be a core module and skipping resolution`);
      return null;
      }
    }
    catch{
      
    }
      // console.log(`unable to resolve module for import path ${originalImportPath} in the file ${contextPath}`)
      return;
  }
   
  // Internal function to resolve path
 // Internal function to resolve path
function resolvePathInternal(modulePath, extensions, mainFields, mainFiles) {
    // Try resolving with extensions
  for (const ext of extensions) {
      if (fs.existsSync(`${modulePath}${ext}`)) {
        return `${modulePath}${ext}`;
      }
  }

  if (fs.existsSync(modulePath)) {
    const stats = fs.statSync(modulePath);
    if (stats.isFile()) {
      return resolveFile(modulePath, extensions);
    } else if (stats.isDirectory()) {
      return resolveDirectory(modulePath, mainFields, mainFiles, extensions);
    }
  }


  return null;
}
   
  // Resolve a file path
  function resolveFile(filePath, extensions) {
    if (path.extname(filePath)) {
      if(fs.existsSync(filePath)&&fs.statSync(filePath).isFile()){
        return filePath;
      }
    }
  
    for (const ext of extensions) {
      const potentialFilePath = `${filePath}${ext}`;
      if (fs.existsSync(potentialFilePath)) {
        return potentialFilePath;
      }
    }
  
    return null;
  }
  function resolveMainFile(dirPath,mainFiles,extensions){
    // Resolve using mainFiles
    for (const file of mainFiles) {
      for (const ext of extensions) {
        const potentialFilePath = path.resolve(dirPath, `${file}${ext}`);
        if (fs.existsSync(potentialFilePath)) {
          return potentialFilePath;
        }
      }
    }
  }
   
  // Resolve a directory path
  function resolveDirectory(dirPath, mainFields, mainFiles, extensions) {
    const packageJsonPath = path.join(dirPath, 'package.json');
    if (fs.existsSync(packageJsonPath)) {
      const packageJson = JSON.parse(fs.readFileSync(packageJsonPath, 'utf-8'));
      // Resolve using mainFields
      for (const field of mainFields) {
        if (packageJson[field]) {
          let resolvedPath = path.resolve(dirPath, packageJson[field]);
          resolvedPath = resolveMainFile(resolvedPath,mainFiles,extensions);
          if(!resolvedPath) resolvedPath = resolveFile(path.resolve(dirPath, packageJson[field]),extensions);
          if (resolvedPath) return path.join(dirPath, 'package.json');
        }
      }
    }
  
    // Resolve using mainFiles
    const resolvedPath = resolveMainFile(dirPath,mainFiles,extensions);
    if(resolvedPath){
      return resolvedPath;
    }
  
    return null;
  }

function resolveImportPath(filePath, importPath) {
  let resolvedDir = importPath;
  // console.log("Initial import path",importPath);
  resolvedDir = tsUnaliasedPath(resolvedDir, path.dirname(filePath));
  // console.log("TSUNALIASED PATH: ",resolvedDir)
  resolvedDir = unaliasedPath(resolvedDir, path.dirname(filePath));
  // console.log("WEBPACK UNALIASED PATH: ",resolvedDir)
  resolvedDir = libToRootConversion(resolvedDir);
  // console.log("LIBCHECK PATH: ",resolvedDir)
  // console.log("input args: ",importPath,resolvedDir,filePath);
  const resolvedPath = moduleResolver(importPath, resolvedDir, path.dirname(filePath));
  // console.log("MODULE RESOLVER PATH: ",resolvedPath)
  if(resolvedPath === undefined) console.log(`unable to resolve import path ${importPath} in file ${filePath}`);
  return resolvedPath;
}

function libToRootConversion(filePath) {
  for (const [prefix, value] of libToPath) {
    if (filePath.startsWith(prefix)) {
      // Replace the prefix with the corresponding value
      const newPath = value + filePath.slice(prefix.length);
      libbedImport.add(filePath);
      return newPath;
    }
  }

  // If no prefix matches, return the original string
  return filePath;
}
function getAbsolutePath(directory, filePath, importPath) {
  makeResolver(directory);
  const absolutePath = resolveImportPath(filePath, importPath);
  if (absolutePath) return absolutePath;
  const projectAbsPath = path.resolve(directory.rootFolder);
  const modulePath = require.resolve(importPath, { paths: [projectAbsPath] });
  // console.log(`modulePath: ${modulePath}`);
  return modulePath;
 
}

module.exports = {getAbsolutePath};
