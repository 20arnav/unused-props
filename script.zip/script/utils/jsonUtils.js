const fs = require('fs');

function appendToJsonFile(filePath, newData) {
  try {
    const data = fs.readFileSync(filePath, 'utf8');
    let json;

    try {
      json = JSON.parse(data);
    } catch (parseErr) {
      console.error('Error parsing JSON:', parseErr);
      return;
    }

    // Assuming json is an array, and newData is the data to be appended
    if (Array.isArray(json)) {
      json.push(newData);
    } else {
      console.error('JSON is not an array');
      return;
    }

    fs.writeFileSync(filePath, JSON.stringify(json, null, 2), 'utf8');
    console.log('Data successfully appended to JSON file');
  } catch (err) {
    console.error('Error reading or writing the file:', err);
  }
}

function initializeJsonFile(filePath) {
  const initialData = [];

  try {
    fs.writeFileSync(filePath, JSON.stringify(initialData, null, 2), 'utf8');
    console.log('JSON file initialized with an empty array');
  } catch (err) {
    console.error('Error initializing the JSON file:', err);
  }
}


function removeDuplicatesFromJsonFile(filePath) {
  try {
    const data = fs.readFileSync(filePath, 'utf8');

    let json;
    try {
      json = data.trim() ? JSON.parse(data) : [];
    } catch (parseErr) {
      console.error('Error parsing JSON:', parseErr);
      return;
    }

    if (!Array.isArray(json)) {
      console.error('JSON is not an array');
      return;
    }

    // Remove duplicates
    const uniqueData = json.filter((item, index, self) => 
      index === self.findIndex((t) => JSON.stringify(t) === JSON.stringify(item))
    );

    fs.writeFileSync(filePath, JSON.stringify(uniqueData, null, 2), 'utf8');
    console.log('Duplicates successfully removed from JSON file');
  } catch (err) {
    console.error('Error reading or writing the file:', err);
  }
}

module.exports = { appendToJsonFile, initializeJsonFile, removeDuplicatesFromJsonFile };
