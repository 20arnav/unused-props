
const PROJECT_DIRECTORY_PATH = '/Users/arnav.goyal/Documents/CrypTracker/';
const ENTRY_FILE_PATH = '/Users/arnav.goyal/Documents/CrypTracker/src/App.js';
const DIRECTORY = {
  rootFolder: PROJECT_DIRECTORY_PATH,
  webpackConfigPath: './webpack.config.js',
};

module.exports = { PROJECT_DIRECTORY_PATH, ENTRY_FILE_PATH, DIRECTORY };
