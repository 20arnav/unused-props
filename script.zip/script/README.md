# Unused Props Identifier

## Description
This project identifies unused props for each component in a react component tree.

## Installation and Usage

1. Clone the repository<br>
2. Install dependencies via `npm install`.<br>
3. Run the npm package that identifies the unused props using `npm start`.<br>
   The following inputs need to be given via command line:<br>
   i) The absolute path of the project directory/repository.<br>
   ii) The absolute path of the root component file.<br>
   iii) The relative path of webpack config (optional, skip this if it does not exist).<br>
   iv) The relative path of tsconfig (optional, skip this if it does not exist).<br>
   v) The relative path of lib folder (optional, skip this if it does not exist).<br>

## Output

The output will be generated in `unused_props_output.json`.<br>
The output contains the following information about each component in the component tree.<br>
i) The name of the component.<br>
ii) The filepath of the component.<br>
iii) The props used by the component.<br>
iv) The props unused by the component.<br>

The folder output will also be created which allows you to see the prop tree created for each individual component which and can see in detail the structure of the props and which props in the tree have been mark visited or unvisited.<br>

## Brief Description of the Source Code

The file `src/scripts/componentScript.js` identifies unused props for a single component.<br>
The file `src/scripts/componentTreeParser.js` builds the component tree with the root as the root component.<br>
The file `src/scripts/componentTreeTraversal.js` is the starting file that runs componentScript.js on each component in the component tree generating the final output.<br>
The file `utils/resolver.js` is the code to resolve the relative file path of the import to absolute path of the import including aliases.<br>

## Authors

**Intern** : Arnav Goyal<br>
**Manager** : Mayank Hinger<br>
**Mentors** : Shubham Tiwari, Paras Sindhwani, Sanchit Gupta, Manish Kumar Golcha<br>

